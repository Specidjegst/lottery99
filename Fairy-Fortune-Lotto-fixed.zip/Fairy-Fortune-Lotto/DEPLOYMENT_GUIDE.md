# 🎰 Fairy Lottery - Complete Deployment Guide

This guide walks you through deploying a production-ready blockchain lottery with Chainlink VRF on Ethereum testnets.

## 📋 Prerequisites

- Node.js 18+ and npm
- MetaMask or similar wallet
- Basic terminal knowledge

## 🚀 Quick Start (Local Development)

```bash
# 1. Install dependencies
npm install
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox @chainlink/contracts dotenv ethers

# 2. Start frontend (mockup mode)
npm run dev

# Frontend runs at http://localhost:5000
```

## 🌐 Testnet Deployment (Production-Ready)

### Step 1: Get Testnet Tokens

**Recommended: Polygon Mumbai** (cheapest gas)

1. **Get Mumbai MATIC:**
   - Visit https://faucet.polygon.technology/
   - Connect your wallet
   - Request testnet MATIC

2. **Get LINK tokens:**
   - Visit https://faucets.chain.link/mumbai
   - Connect wallet
   - Request LINK

**Alternative: Base Sepolia**
- ETH: https://www.coinbase.com/faucets/base-ethereum-sepolia-faucet
- LINK: https://faucets.chain.link/base-sepolia

### Step 2: Setup Environment

Create `.env` file:

```bash
# Wallet private key (KEEP SECRET!)
DEPLOYER_PRIVATE_KEY=your_private_key_here

# RPC URLs (optional - uses public RPCs by default)
POLYGON_MUMBAI_RPC=https://polygon-mumbai.g.alchemy.com/v2/YOUR_KEY
BASE_SEPOLIA_RPC=https://base-sepolia.g.alchemy.com/v2/YOUR_KEY

# Block explorer API keys (for contract verification)
POLYGONSCAN_API_KEY=your_polygonscan_key
BASESCAN_API_KEY=your_basescan_key

# VRF Subscription ID (get this from Step 3)
VRF_SUBSCRIPTION_ID=

# After deployment (get from Step 4)
LOTTERY_CONTRACT_ADDRESS=
```

### Step 3: Create Chainlink VRF Subscription

1. Go to https://vrf.chain.link
2. Connect wallet (select Polygon Mumbai)
3. Click **"Create Subscription"**
4. Confirm transaction
5. **Copy your Subscription ID** → Add to `.env` as `VRF_SUBSCRIPTION_ID`
6. Click **"Add funds"**
7. Fund with **10 LINK** (enough for ~20 draws)

### Step 4: Deploy Smart Contract

```bash
# Compile contract
npm run compile

# Deploy to Polygon Mumbai (RECOMMENDED)
npm run deploy:mumbai

# Or deploy to Base Sepolia
npm run deploy:base-sepolia
```

**Expected output:**
```
🚀 Deploying FairyLottery to polygonMumbai...

✅ FairyLottery deployed to: 0xYourContractAddress

📝 Next steps:
1. Add this contract as a VRF consumer:
   https://vrf.chain.link (Subscription ID: 123)

2. Update frontend config:
   VITE_LOTTERY_CONTRACT_ADDRESS=0xYourContractAddress
   VITE_CHAIN_ID=80001
```

### Step 5: Add Contract as VRF Consumer

1. Go back to https://vrf.chain.link
2. Select your subscription
3. Click **"Add consumer"**
4. Paste your **deployed contract address** (from Step 4)
5. Confirm transaction

### Step 6: Configure Frontend

Update `.env`:

```bash
VITE_LOTTERY_CONTRACT_ADDRESS=0xYourContractAddress
VITE_CHAIN_ID=80001  # 80001 = Mumbai, 84532 = Base Sepolia
VITE_WALLETCONNECT_PROJECT_ID=your_project_id  # Get from cloud.walletconnect.com
```

Get WalletConnect Project ID:
1. Visit https://cloud.walletconnect.com
2. Sign up / Login
3. Create new project
4. Copy Project ID

### Step 7: Install Frontend Dependencies

```bash
npm install wagmi viem @tanstack/react-query @rainbow-me/rainbowkit
```

### Step 8: Start Full Application

```bash
npm run dev
```

Visit http://localhost:5000 and connect your wallet!

## 🎲 Running a Draw

Draws happen automatically every 14 days, but you (as owner) can trigger them manually:

```bash
# Set contract address in .env
LOTTERY_CONTRACT_ADDRESS=0xYourContractAddress

# Request draw (only after 14 days pass)
npm run request-draw -- --network polygonMumbai
```

**What happens:**
1. Contract requests randomness from Chainlink VRF
2. Wait 1-2 minutes
3. Chainlink fulfills request with random numbers
4. Winners are automatically calculated
5. Players can claim prizes

## 💰 Prize Distribution

- **Total Prize Pool** = All ticket sales (100%)
- **Tier 1 (5+2)**: 52%
- **Tier 2 (5+1)**: 18%
- **Tier 3 (5+0)**: 10%
- **Tiers 4-13**: Remaining 20%

Prize per winner = (Tier pool) / (Number of winners in tier)

## 📊 Monitoring & Management

### View Contract on Block Explorer

- **Mumbai**: https://mumbai.polygonscan.com/address/YOUR_CONTRACT
- **Base Sepolia**: https://sepolia.basescan.org/address/YOUR_CONTRACT

### Check VRF Requests

1. Go to https://vrf.chain.link
2. Select your subscription
3. View request history

### Emergency Withdraw (Owner Only)

```javascript
// In case of emergency, owner can withdraw funds
const lottery = await ethers.getContractAt("FairyLottery", CONTRACT_ADDRESS);
await lottery.emergencyWithdraw();
```

## 🔧 Troubleshooting

### "InsufficientPayment" error
- ETH price feed might be outdated
- Try sending slightly more ETH (contract refunds excess)

### VRF request never fulfilled
- Check subscription has enough LINK (2+ LINK)
- Verify contract is added as consumer
- Wait 2-3 minutes (Chainlink needs time)

### Wrong network in MetaMask
- Click network switcher
- Select correct testnet (Mumbai/Base Sepolia)
- Or approve network switch prompt

### Contract not verified
```bash
npx hardhat verify --network polygonMumbai YOUR_CONTRACT_ADDRESS \
  "VRF_COORDINATOR" "SUBSCRIPTION_ID" "KEY_HASH" "CALLBACK_GAS_LIMIT" "PRICE_FEED"
```

## 📱 Production Deployment (Mainnet)

**⚠️ IMPORTANT: Mainnet deployment requires:**
- Audited smart contract
- Significant LINK token budget (~$50-100 per draw)
- Legal compliance for gambling/lottery
- Professional security review

**Mainnet networks:**
- Polygon: Lower gas, cheaper VRF
- Ethereum: Higher security, expensive gas
- Base: L2 with low fees

Contact Chainlink for Enterprise VRF pricing for mainnet.

## 🛠 Development Tips

### Local Testing (Hardhat Network)

```bash
# Start local node
npx hardhat node

# Deploy to local network (no VRF)
npx hardhat run scripts/deploy.js --network localhost
```

Note: Chainlink VRF doesn't work on local networks. Use testnets for full testing.

### Contract Updates

If you modify the contract:
1. Increment version in comments
2. Re-compile: `npm run compile`
3. Deploy new version: `npm run deploy:mumbai`
4. Update `VITE_LOTTERY_CONTRACT_ADDRESS` in `.env`
5. Restart frontend

### Frontend Development (without blockchain)

The app includes a **mockup mode** (default for `npm run dev`). To test UI without deploying:
- Wallet connection is simulated
- Ticket purchases are local-only
- Draw animations work offline

## 📚 Architecture Overview

```
┌─────────────────┐
│   Frontend      │
│  (React+Vite)   │  ← User interface
│   wagmi hooks   │
└────────┬────────┘
         │
         ├──── Wallet (MetaMask/WalletConnect)
         │
┌────────┴────────┐
│  Smart Contract │
│  (FairyLottery) │  ← On-chain lottery logic
└────────┬────────┘
         │
         ├──── Chainlink VRF (randomness)
         ├──── Chainlink Price Feed (ETH/USD)
         │
┌────────┴────────┐
│  Backend API    │  ← Optional: indexing, caching
│  (Express+PG)   │
└─────────────────┘
```

## 📞 Support

- **Chainlink VRF Docs**: https://docs.chain.link/vrf
- **Hardhat Docs**: https://hardhat.org/getting-started
- **wagmi Docs**: https://wagmi.sh

## ⚖️ License

MIT - See LICENSE file

---

**Built with:**
- Solidity 0.8.20
- Chainlink VRF v2.5
- Hardhat
- wagmi + RainbowKit
- React + Vite
