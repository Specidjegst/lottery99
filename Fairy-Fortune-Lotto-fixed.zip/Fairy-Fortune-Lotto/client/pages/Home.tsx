import TicketRoll from "@/components/TicketRoll/TicketRoll";

export default function Home() {
  return (
    <>
      {/* dein bestehender Hero */}
      <TicketRoll total={10000} />
    </>
  );
}