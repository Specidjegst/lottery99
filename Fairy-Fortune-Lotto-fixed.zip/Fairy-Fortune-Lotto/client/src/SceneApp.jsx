import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import LotteryScene from "./components/scene/LotteryScene.jsx";
import NumberPicker from "./components/scene/NumberPicker.jsx";
import TicketCard from "./components/scene/TicketCard.jsx";
import {
  calcMatches,
  nextDrawTimestamp,
  randomDraw,
  uniqueSorted,
  validatePick,
} from "./lib/lottery-utils.js";
import { useCountdown } from "./hooks/useCountdown.js";
import "./scene-styles.css";

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function fmt2(n) {
  return String(n).padStart(2, "0");
}

function storageKey(addr) {
  return `fairy_lottery_tickets:${addr || "guest"}`;
}

export default function SceneApp() {
  const [wallet, setWallet] = useState(null);

  const [pickMain, setPickMain] = useState([]);
  const [pickStars, setPickStars] = useState([]);

  const [tickets, setTickets] = useState([]);

  const [nextDrawTs, setNextDrawTs] = useState(nextDrawTimestamp());
  const cd = useCountdown(nextDrawTs);

  const [phase, setPhase] = useState("idle");
  const [launch, setLaunch] = useState(null);
  const [drawnMain, setDrawnMain] = useState([]);
  const [drawnStars, setDrawnStars] = useState([]);
  const [lastDraw, setLastDraw] = useState(null);

  useEffect(() => {
    const raw = localStorage.getItem(storageKey(wallet));
    if (raw) setTickets(JSON.parse(raw));
    else setTickets([]);
  }, [wallet]);

  useEffect(() => {
    localStorage.setItem(storageKey(wallet), JSON.stringify(tickets));
  }, [tickets, wallet]);

  const countdownText = useMemo(() => {
    if (cd.done) return "ZIEHUNG BEREIT";
    return `${fmt2(cd.days)}:${fmt2(cd.hours)}:${fmt2(cd.minutes)}:${fmt2(cd.seconds)}`;
  }, [cd]);

  const canSubmit = useMemo(() => {
    return validatePick(pickMain, pickStars).ok && phase !== "drawing" && phase !== "reveal";
  }, [pickMain, pickStars, phase]);

  const prizePoolUsd = useMemo(() => {
    const pendingCount = tickets.filter(t => t.status === "pending").length;
    return pendingCount * 5;
  }, [tickets]);

  function autoPick() {
    const main = uniqueSorted(Array.from({ length: 5 }, () => (Math.floor(Math.random() * 50) + 1)));
    const stars = uniqueSorted(Array.from({ length: 2 }, () => (Math.floor(Math.random() * 12) + 1)));
    if (main.length === 5) setPickMain(main);
    if (stars.length === 2) setPickStars(stars);
  }

  function addTicket() {
    const v = validatePick(pickMain, pickStars);
    if (!v.ok) return alert(v.reason);

    const t = {
      id: crypto.randomUUID(),
      ts: Date.now(),
      main: uniqueSorted(pickMain),
      stars: uniqueSorted(pickStars),
      status: "pending",
    };
    setTickets((prev) => [t, ...prev]);
    setPickMain([]);
    setPickStars([]);
  }

  function connectDemo() {
    setWallet((w) => (w ? null : "0xFAE...D00D"));
  }

  async function runDrawSequence() {
    if (phase === "drawing" || phase === "reveal") return;

    const result = randomDraw();

    setLastDraw(result);
    setDrawnMain([]);
    setDrawnStars([]);
    setPhase("drawing");

    await sleep(450);

    for (let i = 0; i < result.main.length; i++) {
      const value = result.main[i];
      setLaunch({ kind: "main", value, index: i });
      await sleep(650);
      setDrawnMain((prev) => [...prev, value]);
      await sleep(120);
      setLaunch(null);
      await sleep(220);
    }

    setPhase("reveal");
    await sleep(300);

    for (let i = 0; i < result.stars.length; i++) {
      const value = result.stars[i];
      setLaunch({ kind: "star", value, index: i });
      await sleep(650);
      setDrawnStars((prev) => [...prev, value]);
      await sleep(120);
      setLaunch(null);
      await sleep(200);
    }

    setPhase("done");
    await sleep(700);
    setPhase("idle");

    setTickets((prev) =>
      prev.map((t) =>
        t.status === "pending"
          ? { ...t, status: "drawn", drawTs: result.ts }
          : t
      )
    );

    setNextDrawTs(nextDrawTimestamp(Date.now() + 1000));
  }

  const ticketMatches = useMemo(() => {
    if (!lastDraw) return new Map();
    const m = new Map();
    tickets.forEach((t) => {
      const hit = calcMatches(t, lastDraw);
      m.set(t.id, {
        ...hit,
        mainHits: t.main.filter((n) => lastDraw.main.includes(n)),
        starHits: t.stars.filter((n) => lastDraw.stars.includes(n)),
      });
    });
    return m;
  }, [tickets, lastDraw]);

  return (
    <div className="app">
      <div className="bg" />
      <div className="noise" />

      <header className="topbar">
        <div className="brand">
          <div className="logoDot" />
          <div className="brandText">
            <div className="brandName">FAE LOTTERY</div>
            <div className="brandSub">enchanted draw experience</div>
          </div>
        </div>

        <div className="topActions">
          <div className="walletBadge">
            <span className={`dot ${wallet ? "on" : ""}`} />
            <span className="mono">{wallet ? wallet : "Nicht verbunden"}</span>
          </div>

          <button className="btn" onClick={connectDemo}>
            {wallet ? "Trennen" : "Wallet verbinden"}
          </button>

          <button className="btn primary" onClick={runDrawSequence}>
            Ziehung starten
          </button>
        </div>
      </header>

      <main className="layout">
        <section className="left">
          <LotteryScene
            phase={phase}
            prizeText={`$${prizePoolUsd.toLocaleString()}`}
            countdownText={countdownText}
            drawnMain={drawnMain}
            drawnStars={drawnStars}
            launch={launch}
          />

          <div className="panel panelWide">
            <div className="panelHead">
              <div>
                <div className="panelTitle">Ticket erstellen</div>
                <div className="panelSub">5 Zahlen + 2 Lucky Stars • $5 pro Ticket</div>
              </div>

              <div className="panelBtns">
                <button className="btn ghost" onClick={autoPick}>
                  Zufall
                </button>
                <button className="btn primary" disabled={!canSubmit} onClick={addTicket}>
                  Ticket hinzufügen
                </button>
              </div>
            </div>

            <div className="pickSummary">
              <div className="summaryBlock">
                <div className="summaryLabel">Zahlen</div>
                <div className="summaryValue mono">{uniqueSorted(pickMain).join(" • ") || "—"}</div>
              </div>
              <div className="summaryBlock">
                <div className="summaryLabel">Stars</div>
                <div className="summaryValue mono">{uniqueSorted(pickStars).map((s) => `${s}`).join(" • ") || "—"}</div>
              </div>
            </div>

            <NumberPicker
              main={pickMain}
              stars={pickStars}
              setMain={setPickMain}
              setStars={setPickStars}
              disabled={phase === "drawing" || phase === "reveal"}
            />
          </div>
        </section>

        <aside className="right">
          <div className="panel">
            <div className="panelHead">
              <div>
                <div className="panelTitle">Meine Tickets</div>
                <div className="panelSub">{tickets.length} Tickets • lokal gespeichert</div>
              </div>
            </div>

            <div className="ticketList">
              {tickets.length === 0 && (
                <div className="empty">
                  <div className="emptyTitle">Noch keine Tickets</div>
                  <div className="emptySub">Wähle Zahlen, dann „Ticket hinzufügen".</div>
                </div>
              )}

              {tickets.map((t, idx) => (
                <motion.div
                  key={t.id}
                  className="ticketWrap"
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 3.2 + (idx % 6) * 0.25, repeat: Infinity, ease: "easeInOut" }}
                >
                  <TicketCard
                    ticket={t}
                    match={lastDraw ? ticketMatches.get(t.id) : null}
                    isActive={idx === 0}
                  />
                </motion.div>
              ))}
            </div>
          </div>

          <div className="panel">
            <div className="panelHead">
              <div>
                <div className="panelTitle">Letzte Ziehung</div>
                <div className="panelSub">{lastDraw ? new Date(lastDraw.ts).toLocaleString() : "—"}</div>
              </div>
            </div>

            {!lastDraw ? (
              <div className="empty">
                <div className="emptyTitle">Keine Ziehung yet</div>
                <div className="emptySub">Klicke „Ziehung starten", um die Fee Kugeln ziehen zu lassen.</div>
              </div>
            ) : (
              <div className="lastDraw">
                <div className="lastRow">
                  {lastDraw.main.map((n) => (
                    <span className="pill main" key={`ldm-${n}`}>{n}</span>
                  ))}
                </div>
                <div className="lastRow">
                  {lastDraw.stars.map((n) => (
                    <span className="pill star" key={`lds-${n}`}>{n}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </aside>
      </main>

      <footer className="foot">
        <span className="muted">
          Demo UI • Für echtes Wallet/VRF später Contract-Events anschließen
        </span>
      </footer>
    </div>
  );
}
