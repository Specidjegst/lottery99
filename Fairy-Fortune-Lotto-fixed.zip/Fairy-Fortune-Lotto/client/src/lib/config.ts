export const APP_NAME = "FaeMillions";

export const DEFAULT_CHAIN = {
  chainId: 11155111,
  name: "Sepolia",
  currency: "ETH",
  explorerBaseUrl: "https://sepolia.etherscan.io",
};

export const LOTTERY_CONFIG = {
  ticketPriceUsd: 5,
  contractAddress: import.meta.env.VITE_LOTTERY_CONTRACT_ADDRESS || "0x0000000000000000000000000000000000000000",
  rpcUrl: import.meta.env.VITE_RPC_URL || "",
};

export const DRAW_CONFIG = {
  cadenceDays: 14,
};
