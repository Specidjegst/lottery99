import { createContext, useContext, useMemo, useState } from "react";
import { DEFAULT_CHAIN } from "./config";

export type WalletProviderId = "metamask" | "phantom";

type WalletState = {
  status: "disconnected" | "connecting" | "connected";
  provider?: WalletProviderId;
  address?: string;
  chainId?: number;
};

const WalletContext = createContext<{
  wallet: WalletState;
  connect: (provider: WalletProviderId) => Promise<void>;
  disconnect: () => void;
  switchToDefaultNetwork: () => Promise<void>;
  isWrongNetwork: boolean;
} | null>(null);

function shortAddr(a?: string) {
  if (!a) return "";
  return `${a.slice(0, 6)}…${a.slice(-4)}`;
}

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [wallet, setWallet] = useState<WalletState>({ status: "disconnected" });

  const isWrongNetwork = !!wallet.chainId && wallet.chainId !== DEFAULT_CHAIN.chainId;

  const connect = async (provider: WalletProviderId) => {
    setWallet({ status: "connecting", provider });

    await new Promise((r) => setTimeout(r, 700));

    // Mocked addresses
    const address =
      provider === "metamask"
        ? "0x7A3E2B1cE9a1C4d2EbbE7A3E2B1cE9a1C4d2EbbE"
        : "0x9cC51E2A0Bf4D3A9a0cC51E2A0Bf4D3A9a0cC51E2";

    // Occasionally simulate wrong network
    const chainId = Math.random() < 0.22 ? 1 : DEFAULT_CHAIN.chainId;

    setWallet({
      status: "connected",
      provider,
      address,
      chainId,
    });
  };

  const disconnect = () => setWallet({ status: "disconnected" });

  const switchToDefaultNetwork = async () => {
    if (wallet.status !== "connected") return;
    setWallet((w) => ({ ...w }));
    await new Promise((r) => setTimeout(r, 500));
    setWallet((w) => ({ ...w, chainId: DEFAULT_CHAIN.chainId }));
  };

  const value = useMemo(
    () => ({
      wallet,
      connect,
      disconnect,
      switchToDefaultNetwork,
      isWrongNetwork,
    }),
    [wallet, isWrongNetwork],
  );

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>;
}

export function useWallet() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within WalletProvider");
  return ctx;
}

export function walletLabel(state: WalletState) {
  if (state.status !== "connected") return "";
  return `${state.provider === "metamask" ? "MetaMask" : "Phantom"} · ${shortAddr(state.address)}`;
}
