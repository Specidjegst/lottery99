export type TicketNumbers = {
  main: number[];
  stars: number[];
};

export type Ticket = {
  id: string;
  drawId: string;
  purchasedAt: number;
  numbers: TicketNumbers;
  txHash?: string;
  status: "pending" | "lost" | "won";
  tier?: string;
};

export type Draw = {
  id: string;
  startsAt: number;
  drawAt: number;
  status: "open" | "drawing" | "complete";
  winningNumbers?: TicketNumbers;
  vrf?: {
    requestTx?: string;
    fulfillTx?: string;
    requestId?: string;
  };
};

export function uniqSorted(nums: number[]) {
  return Array.from(new Set(nums)).sort((a, b) => a - b);
}

export function randomPickUnique(min: number, max: number, count: number) {
  const set = new Set<number>();
  while (set.size < count) {
    const n = Math.floor(Math.random() * (max - min + 1)) + min;
    set.add(n);
  }
  return Array.from(set).sort((a, b) => a - b);
}

export function validateTicketNumbers(numbers: TicketNumbers) {
  const main = uniqSorted(numbers.main);
  const stars = uniqSorted(numbers.stars);

  const errors: string[] = [];
  if (main.length !== 5) errors.push("Pick exactly 5 main numbers.");
  if (stars.length !== 2) errors.push("Pick exactly 2 Lucky Stars.");

  for (const n of main) {
    if (n < 1 || n > 50) errors.push("Main numbers must be between 1–50.");
  }
  for (const s of stars) {
    if (s < 1 || s > 12) errors.push("Lucky Stars must be between 1–12.");
  }

  return {
    ok: errors.length === 0,
    main,
    stars,
    errors,
  };
}

export function matchTier(ticket: TicketNumbers, winning?: TicketNumbers) {
  if (!winning) return { status: "pending" as const, tier: undefined };

  const mainHits = ticket.main.filter((n) => winning.main.includes(n)).length;
  const starHits = ticket.stars.filter((n) => winning.stars.includes(n)).length;

  const key = `${mainHits}+${starHits}`;

  const tiers: Record<string, string> = {
    "5+2": "Jackpot",
    "5+1": "Tier 2",
    "5+0": "Tier 3",
    "4+2": "Tier 4",
    "4+1": "Tier 5",
    "4+0": "Tier 6",
    "3+2": "Tier 7",
    "2+2": "Tier 8",
    "3+1": "Tier 9",
    "3+0": "Tier 10",
    "1+2": "Tier 11",
    "2+1": "Tier 12",
    "2+0": "Tier 13",
  };

  const tier = tiers[key];
  if (!tier) return { status: "lost" as const, tier: undefined };
  return { status: "won" as const, tier };
}
