import { http, createConfig } from 'wagmi'
import { polygonMumbai, baseSepolia, sepolia } from 'wagmi/chains'
import { injected, walletConnect } from 'wagmi/connectors'

const WALLETCONNECT_PROJECT_ID = import.meta.env.VITE_WALLETCONNECT_PROJECT_ID || 'YOUR_WALLETCONNECT_PROJECT_ID'

export const LOTTERY_CONTRACT_ADDRESS = (import.meta.env.VITE_LOTTERY_CONTRACT_ADDRESS || '0x0000000000000000000000000000000000000000') as `0x${string}`

export const DEFAULT_CHAIN_ID = Number(import.meta.env.VITE_CHAIN_ID) || polygonMumbai.id

export const wagmiConfig = createConfig({
  chains: [polygonMumbai, baseSepolia, sepolia],
  connectors: [
    injected({ target: 'metaMask' }),
    walletConnect({
      projectId: WALLETCONNECT_PROJECT_ID,
      showQrModal: true,
    }),
  ],
  transports: {
    [polygonMumbai.id]: http(),
    [baseSepolia.id]: http(),
    [sepolia.id]: http(),
  },
  ssr: false,
})

export const SUPPORTED_CHAINS = [polygonMumbai, baseSepolia, sepolia]

export function getChainById(chainId: number) {
  return SUPPORTED_CHAINS.find((c) => c.id === chainId)
}

export function isChainSupported(chainId?: number) {
  if (!chainId) return false
  return SUPPORTED_CHAINS.some((c) => c.id === chainId)
}
