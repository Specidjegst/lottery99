import { createContext, useContext, useMemo, useState } from "react";
import type { Draw, Ticket, TicketNumbers } from "./lottery";
import { DRAW_CONFIG, LOTTERY_CONFIG } from "./config";
import { matchTier, randomPickUnique } from "./lottery";

function now() {
  return Date.now();
}

function addDays(ts: number, days: number) {
  return ts + days * 24 * 60 * 60 * 1000;
}

function makeDrawId(drawAt: number) {
  const d = new Date(drawAt);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `DRAW-${y}${m}${day}`;
}

function nextDrawFrom(base: number) {
  const drawAt = addDays(base, DRAW_CONFIG.cadenceDays);
  return {
    id: makeDrawId(drawAt),
    startsAt: base,
    drawAt,
    status: "open" as const,
    vrf: {
      requestId: "0xVRF_REQUEST_ID_DEMO",
      requestTx: "0xVRF_REQUEST_TX_DEMO",
      fulfillTx: "0xVRF_FULFILL_TX_DEMO",
    },
  };
}

const LotteryContext = createContext<{
  activeDraw: Draw;
  history: Draw[];
  tickets: Ticket[];
  buyTickets: (items: TicketNumbers[], opts?: { txHash?: string }) => void;
  demoTriggerDraw: () => void;
  prizePoolUsd: number;
} | null>(null);

export function LotteryProvider({ children }: { children: React.ReactNode }) {
  const initialBase = useMemo(() => {
    const t = now();
    // Create a nice countdown by making the draw ~9 days away on first load.
    const base = t - 5 * 24 * 60 * 60 * 1000;
    return base;
  }, []);

  const [history, setHistory] = useState<Draw[]>(() => {
    const base = initialBase;
    const completed1DrawAt = base;
    const completed1: Draw = {
      id: makeDrawId(completed1DrawAt),
      startsAt: addDays(base, -DRAW_CONFIG.cadenceDays),
      drawAt: completed1DrawAt,
      status: "complete",
      winningNumbers: {
        main: [4, 12, 19, 28, 44],
        stars: [3, 11],
      },
      vrf: {
        requestId: "0xVRF_REQUEST_ID_DEMO_OLD",
        requestTx: "0xVRF_REQUEST_TX_DEMO_OLD",
        fulfillTx: "0xVRF_FULFILL_TX_DEMO_OLD",
      },
    };
    return [completed1];
  });

  const [activeDraw, setActiveDraw] = useState<Draw>(() => nextDrawFrom(initialBase));
  const [tickets, setTickets] = useState<Ticket[]>([]);

  const prizePoolUsd = useMemo(() => {
    const count = tickets.filter((t) => t.drawId === activeDraw.id).length;
    return count * LOTTERY_CONFIG.ticketPriceUsd;
  }, [tickets, activeDraw.id]);

  const buyTickets = (items: TicketNumbers[], opts?: { txHash?: string }) => {
    const purchasedAt = now();
    setTickets((prev) => {
      const next: Ticket[] = items.map((numbers, idx) => ({
        id: `T-${purchasedAt}-${idx}-${Math.random().toString(16).slice(2)}`,
        drawId: activeDraw.id,
        purchasedAt,
        numbers,
        txHash: opts?.txHash,
        status: "pending",
      }));
      return [...next, ...prev];
    });
  };

  const demoTriggerDraw = () => {
    setActiveDraw((d) => ({ ...d, status: "drawing" }));

    window.setTimeout(() => {
      const winning = {
        main: randomPickUnique(1, 50, 5),
        stars: randomPickUnique(1, 12, 2),
      };

      setActiveDraw((d) => ({
        ...d,
        status: "complete",
        winningNumbers: winning,
        vrf: {
          requestId: "0xVRF_REQUEST_ID_DEMO_NEW",
          requestTx: "0xVRF_REQUEST_TX_DEMO_NEW",
          fulfillTx: "0xVRF_FULFILL_TX_DEMO_NEW",
        },
      }));

      setTickets((prev) =>
        prev.map((t) => {
          if (t.drawId !== activeDraw.id) return t;
          const res = matchTier(t.numbers, winning);
          return { ...t, status: res.status, tier: res.tier };
        }),
      );

      setHistory((h) => [
        {
          id: activeDraw.id,
          startsAt: activeDraw.startsAt,
          drawAt: activeDraw.drawAt,
          status: "complete",
          winningNumbers: winning,
          vrf: {
            requestId: "0xVRF_REQUEST_ID_DEMO_NEW",
            requestTx: "0xVRF_REQUEST_TX_DEMO_NEW",
            fulfillTx: "0xVRF_FULFILL_TX_DEMO_NEW",
          },
        },
        ...h,
      ]);

      setActiveDraw(() => nextDrawFrom(now()));
    }, 2600);
  };

  return (
    <LotteryContext.Provider value={{ activeDraw, history, tickets, buyTickets, demoTriggerDraw, prizePoolUsd }}>
      {children}
    </LotteryContext.Provider>
  );
}

export function useLottery() {
  const ctx = useContext(LotteryContext);
  if (!ctx) throw new Error("useLottery must be used within LotteryProvider");
  return ctx;
}
