import { useReadContract, useWriteContract, useWaitForTransactionReceipt, useWatchContractEvent } from 'wagmi'
import { parseEther, type Address } from 'viem'
import FairyLotteryAbi from './FairyLottery.abi.json'
import { LOTTERY_CONTRACT_ADDRESS } from '../web3-config'

export function useLotteryContract() {
  const contractConfig = {
    address: LOTTERY_CONTRACT_ADDRESS,
    abi: FairyLotteryAbi,
  }

  return {
    address: LOTTERY_CONTRACT_ADDRESS,
    abi: FairyLotteryAbi,
    config: contractConfig,
  }
}

export function useCurrentDraw() {
  const { config } = useLotteryContract()
  
  return useReadContract({
    ...config,
    functionName: 'getCurrentDraw',
    query: {
      refetchInterval: 10000,
    },
  })
}

export function useDraw(drawId: bigint | undefined) {
  const { config } = useLotteryContract()
  
  return useReadContract({
    ...config,
    functionName: 'getDraw',
    args: drawId ? [drawId] : undefined,
    query: {
      enabled: !!drawId,
      refetchInterval: 10000,
    },
  })
}

export function useTicketPrice() {
  const { config } = useLotteryContract()
  
  return useReadContract({
    ...config,
    functionName: 'getTicketPriceInWei',
    query: {
      refetchInterval: 30000,
    },
  })
}

export function usePlayerTickets(address: Address | undefined) {
  const { config } = useLotteryContract()
  
  return useReadContract({
    ...config,
    functionName: 'getPlayerTickets',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address,
      refetchInterval: 10000,
    },
  })
}

export function useDrawTickets(drawId: bigint | undefined) {
  const { config } = useLotteryContract()
  
  return useReadContract({
    ...config,
    functionName: 'getDrawTickets',
    args: drawId ? [drawId] : undefined,
    query: {
      enabled: !!drawId,
    },
  })
}

export function useBuyTicket() {
  const { writeContract, data: hash, isPending, error } = useWriteContract()
  const { config } = useLotteryContract()
  const { data: ticketPrice } = useTicketPrice()

  const buyTicket = (mainNumbers: number[], starNumbers: number[]) => {
    if (!ticketPrice) {
      throw new Error('Ticket price not loaded')
    }

    if (mainNumbers.length !== 5 || starNumbers.length !== 2) {
      throw new Error('Invalid number selection')
    }

    writeContract({
      ...config,
      functionName: 'buyTicket',
      args: [mainNumbers as [number, number, number, number, number], starNumbers as [number, number]],
      value: ticketPrice,
    })
  }

  const receipt = useWaitForTransactionReceipt({
    hash,
  })

  return {
    buyTicket,
    hash,
    isPending,
    error,
    isConfirming: receipt.isLoading,
    isConfirmed: receipt.isSuccess,
  }
}

export function useClaimPrize() {
  const { writeContract, data: hash, isPending, error } = useWriteContract()
  const { config } = useLotteryContract()

  const claimPrize = (drawId: bigint, ticketIndex: bigint) => {
    writeContract({
      ...config,
      functionName: 'claimPrize',
      args: [drawId, ticketIndex],
    })
  }

  const receipt = useWaitForTransactionReceipt({
    hash,
  })

  return {
    claimPrize,
    hash,
    isPending,
    error,
    isConfirming: receipt.isLoading,
    isConfirmed: receipt.isSuccess,
  }
}

export function useWatchDrawEvents(onDrawFulfilled?: (data: any) => void) {
  const { config } = useLotteryContract()

  useWatchContractEvent({
    ...config,
    eventName: 'DrawFulfilled',
    onLogs(logs) {
      if (onDrawFulfilled) {
        logs.forEach((log) => onDrawFulfilled(log.args))
      }
    },
  })

  useWatchContractEvent({
    ...config,
    eventName: 'TicketPurchased',
    onLogs(logs) {
      console.log('TicketPurchased events:', logs)
    },
  })
}
