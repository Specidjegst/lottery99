import { useEffect, useMemo, useState } from "react";

export function useCountdown(targetTs) {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(id);
  }, []);

  return useMemo(() => {
    const diff = Math.max(0, targetTs - now);
    const totalSeconds = Math.floor(diff / 1000);

    const days = Math.floor(totalSeconds / (24 * 3600));
    const hours = Math.floor((totalSeconds % (24 * 3600)) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    return {
      done: diff === 0,
      diff,
      days,
      hours,
      minutes,
      seconds,
    };
  }, [now, targetTs]);
}
