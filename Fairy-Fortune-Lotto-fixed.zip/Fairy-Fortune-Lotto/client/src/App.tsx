import { Route, Switch, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { queryClient } from "./lib/queryClient";
import { useEffect, lazy, Suspense } from "react";
import Shell from "@/components/shell/Shell";
import Home from "@/pages/home";
import BuyTickets from "@/pages/buy";
import MyTickets from "@/pages/my-tickets";
import Results from "@/pages/results";
import History from "@/pages/history";
import HowItWorks from "@/pages/how-it-works";
import Faq from "@/pages/faq";
import NotFound from "@/pages/not-found";
import { LotteryProvider } from "@/lib/lottery-store";
import { WalletProvider } from "@/lib/wallet-mock";

const RollApp = lazy(() => import("./RollApp"));

function ScrollToTop() {
  const [location] = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "instant" as ScrollBehavior });
  }, [location]);
  return null;
}

function RollWrapper() {
  return (
    <Suspense fallback={<div className="flex h-screen items-center justify-center">Loading...</div>}>
      <RollApp />
    </Suspense>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/buy" component={BuyTickets} />
      <Route path="/tickets" component={MyTickets} />
      <Route path="/results" component={Results} />
      <Route path="/history" component={History} />
      <Route path="/how" component={HowItWorks} />
      <Route path="/faq" component={Faq} />
      <Route path="/scene" component={RollWrapper} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  const [location] = useLocation();
  const isSceneRoute = location === "/scene";

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <WalletProvider>
          <LotteryProvider>
            <ScrollToTop />
            {isSceneRoute ? (
              <RollWrapper />
            ) : (
              <Shell>
                <Router />
              </Shell>
            )}
          </LotteryProvider>
        </WalletProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
