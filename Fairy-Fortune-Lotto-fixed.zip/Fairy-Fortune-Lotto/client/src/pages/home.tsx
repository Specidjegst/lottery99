import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Countdown from "@/components/lottery/Countdown";
import { useLottery } from "@/lib/lottery-store";
import orbImg from "@/assets/images/lottery-orb.png";
import fairyImg from "@/assets/images/fairy.png";
import { Sparkles, Ticket, Wand2 } from "lucide-react";

export default function Home() {
  const { activeDraw, prizePoolUsd } = useLottery();

  return (
    <div className="space-y-10">
      <section className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-[radial-gradient(900px_520px_at_50%_20%,rgba(20,184,166,0.12),transparent_55%),radial-gradient(900px_520px_at_78%_30%,rgba(99,102,241,0.18),transparent_58%),linear-gradient(180deg,rgba(255,255,255,0.05),rgba(255,255,255,0.02))] p-6 shadow-[0_40px_200px_-150px_rgba(0,0,0,0.95)] sm:p-10">
        <div className="absolute inset-0 opacity-70">
          <div className="absolute -left-10 -top-16 h-64 w-64 rounded-full bg-emerald-400/10 blur-3xl" />
          <div className="absolute -right-12 -top-10 h-72 w-72 rounded-full bg-indigo-500/12 blur-3xl" />
          <div className="absolute -bottom-12 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-sky-400/10 blur-3xl" />
        </div>

        <div className="relative grid gap-8 lg:grid-cols-[1.15fr_.85fr] lg:items-center">
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="bg-white/7 text-muted-foreground ring-1 ring-white/10" data-testid="badge-biweekly">
                Every 14 days
              </Badge>
              <Badge className="bg-primary/12 text-primary ring-1 ring-primary/25" data-testid="badge-vrf">
                Chainlink VRF verifiable
              </Badge>
            </div>

            <h1 className="font-serif text-4xl leading-[1.05] tracking-wide text-glow sm:text-6xl" data-testid="text-hero-title">
              A brutal, magical lottery.
              <br />
              The fairy draws.
            </h1>

            <p className="max-w-xl text-sm text-muted-foreground sm:text-base" data-testid="text-hero-subtitle">
              Pick 5 numbers + 2 Lucky Stars, buy multiple tickets, and watch the Fae reveal the winners one-by-one.
              Wallet connect + verifiability are first-class.
            </p>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <Link href="/buy" data-testid="link-cta-buy">
                <Button
                  size="lg"
                  className="w-full rounded-2xl bg-[linear-gradient(135deg,rgba(20,184,166,0.95),rgba(99,102,241,0.9))] text-primary-foreground shadow-[0_30px_140px_-90px_rgba(20,184,166,0.6)]"
                  data-testid="button-cta-buy"
                >
                  <Wand2 className="mr-2 h-5 w-5" />
                  Tickets kaufen
                </Button>
              </Link>
              <Link href="/tickets" data-testid="link-cta-tickets">
                <Button variant="secondary" size="lg" className="w-full rounded-2xl bg-white/6 ring-1 ring-white/10" data-testid="button-cta-tickets">
                  <Ticket className="mr-2 h-5 w-5" />
                  My tickets
                </Button>
              </Link>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="glass rounded-3xl p-5">
                <div className="flex items-center justify-between">
                  <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground" data-testid="text-next-draw-label">
                    Next draw
                  </div>
                  <div className="inline-flex items-center gap-1 text-xs text-primary" data-testid="text-draw-id">
                    <Sparkles className="h-4 w-4" />
                    {activeDraw.id}
                  </div>
                </div>
                <div className="mt-3">
                  <Countdown targetTs={activeDraw.drawAt} />
                </div>
              </div>

              <div className="glass rounded-3xl p-5">
                <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground" data-testid="text-prizepool-label">
                  Prize pool (this draw)
                </div>
                <div className="mt-2 font-serif text-4xl tracking-wide text-glow" data-testid="text-prizepool-value">
                  ${prizePoolUsd.toLocaleString()}
                  <span className="ml-2 text-base text-muted-foreground">USD</span>
                </div>
                <div className="mt-3 text-xs text-muted-foreground" data-testid="text-prizepool-note">
                  Based on tickets purchased for {activeDraw.id}.
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 rounded-[2.2rem] bg-[radial-gradient(circle_at_30%_25%,rgba(20,184,166,0.25),transparent_55%),radial-gradient(circle_at_70%_70%,rgba(99,102,241,0.22),transparent_55%)] blur-2xl" />
            <div className="relative grid gap-3 rounded-[2rem] border border-white/10 bg-white/5 p-4 backdrop-blur-xl">
              <div className="relative overflow-hidden rounded-[1.6rem] bg-black/30">
                <img src={orbImg} alt="Lottery orb" className="h-full w-full object-cover" data-testid="img-orb" />
              </div>
              <div className="grid grid-cols-[1fr_auto] items-end gap-3">
                <div>
                  <div className="text-sm font-semibold" data-testid="text-mascot-title">Meet the Fairy</div>
                  <div className="mt-1 text-xs text-muted-foreground" data-testid="text-mascot-subtitle">
                    She performs the draw animation and reveals numbers with sparkles.
                  </div>
                </div>
                <img src={fairyImg} alt="Fairy mascot" className="h-20 w-20 object-contain drop-shadow-[0_30px_80px_rgba(0,0,0,0.75)]" data-testid="img-fairy" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-3">
        <Feature title="Pick & Quick-pick" desc="No duplicates, clean validation, keyboard-friendly picker." testId="feature-1" />
        <Feature title="Verifizierbare Ziehung" desc="Ziehung‑ID + VRF Request/Fulfill Links direkt im UI." testId="feature-2" />
        <Feature title="Game-like reveal" desc="Fairy sequence, particles, sound hooks, and results banner." testId="feature-3" />
      </section>
    </div>
  );
}

function Feature({ title, desc, testId }: { title: string; desc: string; testId: string }) {
  return (
    <div className="glass rounded-3xl p-5" data-testid={`card-${testId}`}>
      <div className="font-semibold" data-testid={`text-${testId}-title`}>{title}</div>
      <div className="mt-2 text-sm text-muted-foreground" data-testid={`text-${testId}-desc`}>{desc}</div>
    </div>
  );
}
