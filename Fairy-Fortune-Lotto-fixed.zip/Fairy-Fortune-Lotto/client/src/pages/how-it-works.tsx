import { Card } from "@/components/ui/card";

export default function HowItWorks() {
  return (
    <div className="space-y-6">
      <div>
        <div className="font-serif text-3xl tracking-wide text-glow" data-testid="text-how-title">Wie funktioniert’s?</div>
        <div className="mt-1 text-sm text-muted-foreground" data-testid="text-how-subtitle">
          Kurz & verständlich \u2014 EuroMillions-Prinzip, alle 14 Tage eine Ziehung.
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Section title="1) Ticket auswählen" testId="how-1">
          Du wählst <b>5 Zahlen (1–50)</b> und <b>2 Lucky Stars (1–12)</b>. Keine Duplikate \u2014 das UI verhindert das.
        </Section>
        <Section title="2) Wallet verbinden" testId="how-2">
          Verbinde <b>MetaMask</b> oder <b>Phantom (EVM)</b>. Wenn du im falschen Netzwerk bist, bekommst du eine freundliche Aufforderung zum Wechsel.
        </Section>
        <Section title="3) Kaufen & warten" testId="how-3">
          Du kannst mehrere Tickets auf einmal kaufen. Danach erscheinen sie sofort unter <b>„My Tickets“</b>.
        </Section>
        <Section title="4) Ziehung (Chainlink VRF)" testId="how-4">
          In einer echten Version fordert der Vertrag Zufall über <b>Chainlink VRF</b> an \u2014 nachvollziehbar und überprüfbar. In dieser Demo ist das Verhalten simuliert.
        </Section>
      </div>

      <div className="glass rounded-3xl p-6" data-testid="panel-how-note">
        <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground" data-testid="text-how-note-title">Hinweis</div>
        <div className="mt-2 text-sm text-muted-foreground" data-testid="text-how-note-body">
          Diese App ist ein Frontend-Prototyp: On-chain Logik, Contract, VRF und Automation sind hier nur als UI/Flow dargestellt.
          Für Produktion würden wir Wallet-Connector + Contract Calls sauber anbinden und Draws via Chainlink Automation timen.
        </div>
      </div>
    </div>
  );
}

function Section({ title, children, testId }: { title: string; children: React.ReactNode; testId: string }) {
  return (
    <Card className="glass rounded-3xl border-white/10 p-6" data-testid={`card-${testId}`}>
      <div className="font-semibold" data-testid={`text-${testId}-title`}>{title}</div>
      <div className="mt-2 text-sm text-muted-foreground" data-testid={`text-${testId}-body`}>{children}</div>
    </Card>
  );
}
