import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-140px)] grid place-items-center px-6">
      <div className="glass neon-ring w-full max-w-lg rounded-3xl p-8">
        <div className="font-serif text-3xl tracking-wide text-glow" data-testid="text-404-title">
          404 — Lost in the forest
        </div>
        <p className="mt-3 text-sm text-muted-foreground" data-testid="text-404-subtitle">
          This path doesn’t exist yet. Head back to the portal.
        </p>
        <div className="mt-6">
          <Link href="/" data-testid="link-back-home">
            <Button className="gap-2" data-testid="button-back-home">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
