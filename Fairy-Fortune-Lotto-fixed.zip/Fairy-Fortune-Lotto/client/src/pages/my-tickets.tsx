import { useMemo, useState } from "react";
import { useLottery } from "@/lib/lottery-store";
import TicketCard from "@/components/lottery/TicketCard";
import { Button } from "@/components/ui/button";

export default function MyTickets() {
  const { tickets, activeDraw } = useLottery();
  const [filter, setFilter] = useState<string>("all");

  const drawIds = useMemo(() => {
    const ids = new Set<string>([activeDraw.id]);
    for (const t of tickets) ids.add(t.drawId);
    return Array.from(ids);
  }, [tickets, activeDraw.id]);

  const filtered = useMemo(() => {
    if (filter === "all") return tickets;
    return tickets.filter((t) => t.drawId === filter);
  }, [tickets, filter]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="font-serif text-3xl tracking-wide text-glow" data-testid="text-tickets-title">Meine Tickets</div>
          <div className="mt-1 text-sm text-muted-foreground" data-testid="text-tickets-subtitle">
            Tickets erscheinen sofort nach dem Kauf.
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2" data-testid="controls-ticket-filter">
          <Button
            variant={filter === "all" ? "default" : "secondary"}
            className={filter === "all" ? "rounded-2xl" : "rounded-2xl bg-white/6 ring-1 ring-white/10"}
            onClick={() => setFilter("all")}
            data-testid="button-filter-all"
          >
            All
          </Button>
          {drawIds.slice(0, 4).map((id) => (
            <Button
              key={id}
              variant={filter === id ? "default" : "secondary"}
              className={filter === id ? "rounded-2xl" : "rounded-2xl bg-white/6 ring-1 ring-white/10"}
              onClick={() => setFilter(id)}
              data-testid={`button-filter-${id}`}
            >
              {id}
            </Button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="glass rounded-3xl p-8 text-center" data-testid="empty-tickets">
          <div className="font-semibold" data-testid="text-empty-title">No tickets yet</div>
          <div className="mt-2 text-sm text-muted-foreground" data-testid="text-empty-desc">
            Go to Buy to create your first ticket.
          </div>
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2" data-testid="grid-tickets">
          {filtered.map((t) => (
            <TicketCard key={t.id} ticket={t} />
          ))}
        </div>
      )}
    </div>
  );
}
