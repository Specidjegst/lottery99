import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export default function Faq() {
  return (
    <div className="space-y-6">
      <div>
        <div className="font-serif text-3xl tracking-wide text-glow" data-testid="text-faq-title">FAQ</div>
        <div className="mt-1 text-sm text-muted-foreground" data-testid="text-faq-subtitle">
          Antworten \u2014 kurz, klar, deutschfreundlich.
        </div>
      </div>

      <div className="glass rounded-3xl p-2" data-testid="panel-faq">
        <Accordion type="single" collapsible>
          <AccordionItem value="item-1">
            <AccordionTrigger data-testid="faq-what-is">Was ist FaeMillions?</AccordionTrigger>
            <AccordionContent data-testid="faq-what-is-content">
              Eine Lottery im EuroMillions-Prinzip: <b>5 Zahlen + 2 Stars</b>, Ziehung alle <b>14 Tage</b> \u2014 mit Gaming-Feeling.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-2">
            <AccordionTrigger data-testid="faq-vrf">Was bringt Chainlink VRF?</AccordionTrigger>
            <AccordionContent data-testid="faq-vrf-content">
              VRF liefert nachweisbaren Zufall: Man sieht Request & Fulfill und kann die Fairness transparent prüfen.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-3">
            <AccordionTrigger data-testid="faq-automation">Wie wird die Ziehung getriggert?</AccordionTrigger>
            <AccordionContent data-testid="faq-automation-content">
              In Produktion würde man <b>Chainlink Automation</b> nutzen. In dieser Demo gibt’s einen Button \u201eTrigger draw\u201c.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-4">
            <AccordionTrigger data-testid="faq-claim">Kann ich Gewinne claimen?</AccordionTrigger>
            <AccordionContent data-testid="faq-claim-content">
              In diesem Prototyp sind Gewinne nur deterministisch berechnet und angezeigt. \n              „Claim“ wäre ein Contract-Feature (nicht implementiert im Mockup).
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
}
