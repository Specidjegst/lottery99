import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useLottery } from "@/lib/lottery-store";
import VrfPanel from "@/components/lottery/VrfPanel";
import fairyImg from "@/assets/images/fairy.png";
import particlesImg from "@/assets/images/particles.png";

function chip(kind: "main" | "star") {
  return kind === "star" ? "bg-yellow-400/15 ring-yellow-400/25" : "bg-primary/15 ring-primary/25";
}

export default function Results() {
  const { activeDraw, history, demoTriggerDraw } = useLottery();
  const latest = history[0];

  const [sequence, setSequence] = useState<"idle" | "filling" | "revealing" | "done">("idle");
  const [revealIndex, setRevealIndex] = useState(0);

  const winning = latest.winningNumbers;
  const flat = useMemo(() => {
    if (!winning) return [];
    return [...winning.main.map((n) => ({ kind: "main" as const, n })), ...winning.stars.map((n) => ({ kind: "star" as const, n }))];
  }, [winning]);

  const startShow = async () => {
    if (flat.length === 0) return;

    setSequence("filling");
    setRevealIndex(0);

    await new Promise((r) => setTimeout(r, 900));
    setSequence("revealing");

    for (let i = 1; i <= flat.length; i++) {
      await new Promise((r) => setTimeout(r, 520));
      setRevealIndex(i);
    }

    await new Promise((r) => setTimeout(r, 500));
    setSequence("done");
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_.95fr]">
      <div className="space-y-5">
        <div>
          <div className="font-serif text-3xl tracking-wide text-glow" data-testid="text-results-title">Ergebnisse</div>
          <div className="mt-1 text-sm text-muted-foreground" data-testid="text-results-subtitle">
            Schau zu, wie die Fee die Gewinnzahlen nacheinander enthüllt. (Demo-Animation + Sound-Hooks als Stub.)
          </div>
        </div>

        <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-[radial-gradient(900px_520px_at_50%_20%,rgba(20,184,166,0.12),transparent_55%),radial-gradient(900px_520px_at_78%_30%,rgba(99,102,241,0.18),transparent_58%),linear-gradient(180deg,rgba(255,255,255,0.05),rgba(255,255,255,0.02))] p-6 sm:p-8" data-testid="panel-draw-stage">
          <div className="absolute inset-0 opacity-25">
            <img src={particlesImg} alt="Particles" className="h-full w-full object-cover" />
          </div>

          <div className="relative grid gap-6 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground" data-testid="text-stage-draw-label">Aktuelle Ziehung</div>
              <div className="mt-1 font-serif text-3xl tracking-wide" data-testid="text-stage-draw-id">{activeDraw.id}</div>
              <div className="mt-2 text-sm text-muted-foreground" data-testid="text-stage-draw-note">
                Production: operator triggers VRF request → fulfillment → on-chain stored result.
              </div>

              <div className="mt-5 flex flex-wrap gap-2">
                <Button
                  className="rounded-2xl bg-[linear-gradient(135deg,rgba(20,184,166,0.95),rgba(99,102,241,0.9))] text-primary-foreground"
                  onClick={startShow}
                  data-testid="button-start-reveal"
                >
                  Enthüllung starten
                </Button>
                <Button
                  variant="secondary"
                  className="rounded-2xl bg-white/6 ring-1 ring-white/10"
                  onClick={demoTriggerDraw}
                  data-testid="button-demo-trigger-draw"
                >
                  Demo: Ziehung starten
                </Button>
              </div>
            </div>

            <div className="relative">
              <motion.img
                src={fairyImg}
                alt="Fairy"
                className="h-44 w-44 object-contain drop-shadow-[0_40px_120px_rgba(0,0,0,0.85)]"
                animate={sequence === "revealing" ? { y: [0, -8, 0], rotate: [0, -2, 0] } : { y: 0, rotate: 0 }}
                transition={sequence === "revealing" ? { duration: 1.6, repeat: Infinity, ease: "easeInOut" } : { duration: 0.2 }}
                data-testid="img-fairy-stage"
              />
            </div>
          </div>

          <div className="relative mt-6 rounded-3xl bg-black/25 p-5 ring-1 ring-white/10">
            <div className="flex items-center justify-between">
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground" data-testid="text-winning-label">Winning numbers</div>
              <div className="text-xs text-muted-foreground" data-testid="text-reveal-status">
                {sequence === "idle" ? "Ready" : sequence === "filling" ? "Machine filling…" : sequence === "revealing" ? "Revealing…" : "Complete"}
              </div>
            </div>

            <div className="relative mt-4" data-testid="row-winning-reveal">
              <div className="pointer-events-none absolute -inset-6 opacity-40 blur-2xl">
                <div className="absolute left-1/4 top-1/3 h-24 w-24 rounded-full bg-primary/25" />
                <div className="absolute right-1/4 top-1/2 h-24 w-24 rounded-full bg-indigo-500/20" />
                <div className="absolute left-1/2 bottom-0 h-28 w-28 -translate-x-1/2 rounded-full bg-emerald-400/15" />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <AnimatePresence>
                  {flat.slice(0, revealIndex).map((x, idx) => (
                    <motion.div
                      key={`${x.kind}-${x.n}`}
                      initial={{ opacity: 0, y: 18, scale: 0.75, rotate: -6, filter: "blur(12px)" }}
                      animate={{
                        opacity: 1,
                        y: 0,
                        scale: 1,
                        rotate: 0,
                        filter: "blur(0px)",
                        boxShadow:
                          x.kind === "star"
                            ? "0 0 0 1px rgba(250,204,21,0.22), 0 30px 90px -60px rgba(250,204,21,0.55)"
                            : "0 0 0 1px rgba(20,184,166,0.22), 0 30px 90px -60px rgba(20,184,166,0.55)",
                      }}
                      exit={{ opacity: 0, scale: 0.92, y: -10 }}
                      transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                      className={
                        "relative grid h-12 w-12 place-items-center rounded-full text-sm font-semibold ring-1 " +
                        chip(x.kind)
                      }
                      data-testid={`ball-reveal-${idx}`}
                    >
                      <motion.span
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ duration: 0.25, delay: 0.1 }}
                        className="relative z-10"
                      >
                        {x.n}
                      </motion.span>

                      <motion.span
                        aria-hidden
                        className={
                          "pointer-events-none absolute inset-0 rounded-full opacity-0 " +
                          (x.kind === "star" ? "bg-yellow-400/25" : "bg-primary/25")
                        }
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: [0, 0.55, 0], scale: [0.85, 1.25, 1.35] }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                      />

                      <motion.span
                        aria-hidden
                        className={
                          "pointer-events-none absolute -inset-2 rounded-full opacity-30 blur-lg " +
                          (x.kind === "star" ? "bg-yellow-300/20" : "bg-primary/20")
                        }
                        initial={{ scale: 0.85, opacity: 0 }}
                        animate={{ scale: [0.9, 1.1, 1], opacity: [0, 0.4, 0.22] }}
                        transition={{ duration: 1.2, ease: "easeInOut" }}
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>

            {sequence === "done" ? (
              <div className="mt-5 rounded-2xl bg-primary/10 p-4 ring-1 ring-primary/25" data-testid="banner-results">
                <div className="font-semibold" data-testid="text-banner-title">The fairy has spoken.</div>
                <div className="mt-1 text-sm text-muted-foreground" data-testid="text-banner-subtitle">
                  Tickets are evaluated deterministically in this demo. “Claim” is stubbed.
                </div>
              </div>
            ) : null}
          </div>
        </div>

        <WinnersTable />
      </div>

      <div className="space-y-4">
        <VrfPanel draw={latest} />
      </div>
    </div>
  );
}

function WinnersTable() {
  const rows = [
    { k: "5 + 2", v: 0 },
    { k: "5 + 1", v: 1 },
    { k: "5 + 0", v: 3 },
    { k: "4 + 2", v: 8 },
    { k: "4 + 1", v: 19 },
    { k: "4 + 0", v: 56 },
    { k: "3 + 2", v: 120 },
    { k: "2 + 2", v: 310 },
    { k: "3 + 1", v: 940 },
    { k: "2 + 1", v: 2100 },
  ];

  return (
    <div className="glass rounded-3xl p-6" data-testid="panel-winners">
      <div className="flex items-end justify-between gap-3">
        <div>
          <div className="font-serif text-2xl tracking-wide" data-testid="text-winners-title">Winners</div>
          <div className="mt-1 text-sm text-muted-foreground" data-testid="text-winners-subtitle">
            Demo distribution (on-chain claiming not implemented in mockup).
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-2" data-testid="table-winners">
        {rows.map((r) => (
          <div key={r.k} className="flex items-center justify-between rounded-2xl bg-white/4 px-4 py-3 ring-1 ring-white/10" data-testid={`row-winner-${r.k.replace(/\s+/g, "")}`}>
            <div className="text-sm text-muted-foreground">Matched</div>
            <div className="font-mono text-xs text-foreground/90">{r.k}</div>
            <div className="text-sm text-muted-foreground">Tickets</div>
            <div className="font-semibold">{r.v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
