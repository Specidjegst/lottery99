import { useLottery } from "@/lib/lottery-store";
import VrfPanel from "@/components/lottery/VrfPanel";

function BallRow({
  main,
  stars,
  testId,
}: {
  main: number[];
  stars: number[];
  testId: string;
}) {
  return (
    <div className="mt-3 flex flex-wrap items-center gap-2" data-testid={testId}>
      {main.map((n) => (
        <div key={n} className="grid h-9 w-9 place-items-center rounded-full bg-primary/15 text-sm font-semibold ring-1 ring-primary/25" data-testid={`${testId}-main-${n}`}>{n}</div>
      ))}
      <div className="mx-1 h-5 w-px bg-white/10" />
      {stars.map((n) => (
        <div key={n} className="grid h-9 w-9 place-items-center rounded-full bg-yellow-400/15 text-sm font-semibold ring-1 ring-yellow-400/25" data-testid={`${testId}-star-${n}`}>{n}</div>
      ))}
    </div>
  );
}

export default function History() {
  const { history } = useLottery();

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_.95fr]">
      <div className="space-y-4">
        <div>
          <div className="font-serif text-3xl tracking-wide text-glow" data-testid="text-history-title">Ziehungs‑Historie</div>
          <div className="mt-1 text-sm text-muted-foreground" data-testid="text-history-subtitle">
            Vergangene Ziehungen und Gewinnzahlen.
          </div>
        </div>

        {history.map((d) => (
          <div key={d.id} className="glass rounded-3xl p-6" data-testid={`card-draw-${d.id}`}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground" data-testid={`text-draw-label-${d.id}`}>Ziehung</div>
                <div className="font-serif text-2xl tracking-wide" data-testid={`text-draw-id-${d.id}`}>{d.id}</div>
                <div className="mt-1 text-sm text-muted-foreground" data-testid={`text-draw-date-${d.id}`}>{new Date(d.drawAt).toLocaleString()}</div>
              </div>
              <div className="rounded-full bg-primary/12 px-3 py-1 text-xs text-primary ring-1 ring-primary/25" data-testid={`status-draw-${d.id}`}>Complete</div>
            </div>

            {d.winningNumbers ? (
              <BallRow main={d.winningNumbers.main} stars={d.winningNumbers.stars} testId={`row-winning-${d.id}`} />
            ) : null}
          </div>
        ))}
      </div>

      <div className="space-y-4">
        <VrfPanel draw={history[0]} />
      </div>
    </div>
  );
}
