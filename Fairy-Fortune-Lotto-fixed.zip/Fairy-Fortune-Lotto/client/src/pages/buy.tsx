import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import NumberPicker from "@/components/lottery/NumberPicker";
import { randomPickUnique, validateTicketNumbers } from "@/lib/lottery";
import { useLottery } from "@/lib/lottery-store";
import { useWallet } from "@/lib/wallet-mock";
import { DEFAULT_CHAIN, LOTTERY_CONFIG } from "@/lib/config";
import { Trash2, Wand2 } from "lucide-react";

type Draft = { main: number[]; stars: number[] };

export default function BuyTickets() {
  const { toast } = useToast();
  const { buyTickets, activeDraw } = useLottery();
  const { wallet, isWrongNetwork, switchToDefaultNetwork } = useWallet();

  const [draft, setDraft] = useState<Draft>({ main: [], stars: [] });
  const [cart, setCart] = useState<Draft[]>([]);
  const [count, setCount] = useState("1");
  const [confirmOpen, setConfirmOpen] = useState(false);

  const validation = useMemo(() => validateTicketNumbers(draft), [draft]);

  const quickPick = () => {
    setDraft({ main: randomPickUnique(1, 50, 5), stars: randomPickUnique(1, 12, 2) });
  };

  const clearDraft = () => setDraft({ main: [], stars: [] });

  const addToCart = () => {
    if (!validation.ok) {
      toast({ title: "Ticket incomplete", description: validation.errors.join(" ") });
      return;
    }
    setCart((c) => [{ main: validation.main, stars: validation.stars }, ...c]);
    clearDraft();
    toast({ title: "Added to cart", description: "Ticket added. You can add more." });
  };

  const addMultipleQuickPicks = () => {
    const n = Math.max(1, Math.min(20, parseInt(count || "1", 10) || 1));
    const items: Draft[] = Array.from({ length: n }).map(() => ({
      main: randomPickUnique(1, 50, 5),
      stars: randomPickUnique(1, 12, 2),
    }));
    setCart((c) => [...items, ...c]);
    toast({ title: `Quick-picked ${n} tickets`, description: "Ready in your cart." });
  };

  const removeFromCart = (idx: number) => setCart((c) => c.filter((_, i) => i !== idx));
  const clearCart = () => setCart([]);

  const total = cart.length * LOTTERY_CONFIG.ticketPriceUsd;

  const buy = () => {
    if (wallet.status !== "connected") {
      toast({ title: "Connect wallet", description: "Connect MetaMask or Phantom to buy tickets." });
      return;
    }
    if (isWrongNetwork) {
      toast({ title: "Wrong network", description: `Switch to ${DEFAULT_CHAIN.name} to buy.` });
      return;
    }
    if (cart.length === 0) {
      toast({ title: "Cart empty", description: "Add at least one ticket." });
      return;
    }

    setConfirmOpen(true);
  };

  const confirmBuy = () => {
    // Demo tx hash
    const txHash = "0xDEMO_TX_HASH_" + Math.random().toString(16).slice(2);
    buyTickets(cart, { txHash });
    setConfirmOpen(false);
    clearCart();
    toast({ title: "Erfolg", description: "Tickets gekauft und unter \"Meine Tickets\" angezeigt." });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_.9fr]">
      <div className="space-y-5">
        <div className="glass rounded-3xl p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="font-serif text-3xl tracking-wide text-glow" data-testid="text-buy-title">Ticket kaufen</div>
              <div className="mt-1 text-sm text-muted-foreground" data-testid="text-buy-subtitle">
                Ziehung: <span className="text-foreground">{activeDraw.id}</span> · Wähle 5 + 2.
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button variant="secondary" className="rounded-2xl bg-white/6 ring-1 ring-white/10" onClick={quickPick} data-testid="button-quick-pick">
                <Wand2 className="mr-2 h-4 w-4" />
                Quick-pick
              </Button>
              <Button variant="secondary" className="rounded-2xl bg-white/6 ring-1 ring-white/10" onClick={clearDraft} data-testid="button-clear-draft">
                Clear
              </Button>
            </div>
          </div>

          <div className="mt-6 space-y-8">
            <NumberPicker
              kind="main"
              min={1}
              max={50}
              picks={5}
              selected={draft.main}
              onChange={(next) => setDraft((d) => ({ ...d, main: next }))}
              label="Main numbers"
              testIdPrefix="main"
            />
            <NumberPicker
              kind="star"
              min={1}
              max={12}
              picks={2}
              selected={draft.stars}
              onChange={(next) => setDraft((d) => ({ ...d, stars: next }))}
              label="Lucky Stars"
              testIdPrefix="stars"
            />
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Button
              className="rounded-2xl bg-[linear-gradient(135deg,rgba(20,184,166,0.95),rgba(99,102,241,0.9))] text-primary-foreground"
              onClick={addToCart}
              data-testid="button-add-cart"
            >
              Add to cart
            </Button>
            <Button variant="secondary" className="rounded-2xl bg-white/6 ring-1 ring-white/10" onClick={buy} data-testid="button-buy-now">
              Buy now
            </Button>

            {isWrongNetwork ? (
              <Button
                variant="secondary"
                className="rounded-2xl bg-red-500/10 text-red-100 ring-1 ring-red-500/20"
                onClick={switchToDefaultNetwork}
                data-testid="button-fix-network"
              >
                Switch to {DEFAULT_CHAIN.name}
              </Button>
            ) : null}
          </div>

          {!validation.ok ? (
            <div className="mt-4 rounded-2xl bg-white/5 p-4 ring-1 ring-white/10" data-testid="panel-validation">
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Validation</div>
              <ul className="mt-2 list-disc pl-5 text-sm text-muted-foreground">
                {validation.errors.map((e) => (
                  <li key={e} data-testid={`text-validation-${e.replace(/\s+/g, "-")}`}>{e}</li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      </div>

      <div className="space-y-5">
        <div className="glass rounded-3xl p-6">
          <div className="flex items-end justify-between gap-3">
            <div>
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground" data-testid="text-cart-label">Cart</div>
              <div className="font-serif text-2xl tracking-wide" data-testid="text-cart-count">{cart.length} tickets</div>
            </div>
            <Button variant="secondary" className="rounded-2xl bg-white/6 ring-1 ring-white/10" onClick={clearCart} data-testid="button-clear-cart">
              Clear
            </Button>
          </div>

          <div className="mt-4 flex items-center gap-2">
            <Input value={count} onChange={(e) => setCount(e.target.value)} className="h-10 w-20 rounded-2xl bg-white/5 ring-1 ring-white/10" data-testid="input-quickpick-count" />
            <Button variant="secondary" className="rounded-2xl bg-white/6 ring-1 ring-white/10" onClick={addMultipleQuickPicks} data-testid="button-bulk-quickpick">
              Quick-pick xN
            </Button>
          </div>

          <div className="mt-4 space-y-3" data-testid="list-cart">
            {cart.length === 0 ? (
              <div className="rounded-2xl bg-white/4 p-4 text-sm text-muted-foreground ring-1 ring-white/10" data-testid="text-cart-empty">
                No tickets yet. Add one from the picker.
              </div>
            ) : (
              cart.map((t, idx) => (
                <div key={idx} className="rounded-2xl bg-white/4 p-4 ring-1 ring-white/10" data-testid={`row-cart-${idx}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="text-sm font-semibold" data-testid={`text-cart-ticket-${idx}`}>Ticket #{cart.length - idx}</div>
                    <Button size="icon" variant="secondary" className="h-9 w-9 rounded-2xl bg-white/6 ring-1 ring-white/10" onClick={() => removeFromCart(idx)} data-testid={`button-remove-cart-${idx}`}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {t.main.map((n) => (
                      <div key={n} className="grid h-9 w-9 place-items-center rounded-full bg-primary/15 text-sm font-semibold ring-1 ring-primary/25" data-testid={`ball-cart-main-${idx}-${n}`}>{n}</div>
                    ))}
                    <div className="mx-1 h-5 w-px bg-white/10" />
                    {t.stars.map((n) => (
                      <div key={n} className="grid h-9 w-9 place-items-center rounded-full bg-yellow-400/15 text-sm font-semibold ring-1 ring-yellow-400/25" data-testid={`ball-cart-star-${idx}-${n}`}>{n}</div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="mt-5 rounded-2xl bg-white/5 p-4 ring-1 ring-white/10">
            <div className="flex items-center justify-between text-sm">
              <div className="text-muted-foreground" data-testid="text-total-label">Total</div>
              <div className="font-semibold" data-testid="text-total-value">${total.toFixed(2)}</div>
            </div>
            <div className="mt-3">
              <Button
                size="lg"
                className="w-full rounded-2xl bg-[linear-gradient(135deg,rgba(20,184,166,0.95),rgba(99,102,241,0.9))] text-primary-foreground"
                onClick={buy}
                data-testid="button-checkout"
              >
                Checkout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle data-testid="text-confirm-title">Confirm purchase</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 text-sm text-muted-foreground" data-testid="text-confirm-body">
            You’re about to buy <span className="text-foreground font-semibold">{cart.length}</span> ticket(s) for draw <span className="text-foreground font-semibold">{activeDraw.id}</span>.
            This is a frontend demo: the transaction hash is simulated.
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setConfirmOpen(false)} data-testid="button-cancel-buy">Cancel</Button>
            <Button onClick={confirmBuy} data-testid="button-confirm-buy">Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
