import React, { forwardRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ticketRollImg from "../../assets/images/ticket-roll.webp";
import "./TicketRoll.css";

const TicketRoll = forwardRef(function TicketRoll({ remaining, total, portRef }, ref) {
  const sold = total - remaining;
  const isEmpty = remaining <= 0;

  return (
    <div className="ticket-roll-component" ref={ref}>
      <div className="ticket-roll-image-card">
        <img
          src={ticketRollImg}
          alt="Ticket Rolle"
          className="ticket-roll-image"
        />
        <div className="ticket-roll-port" ref={portRef} />

        <AnimatePresence>
          {isEmpty && (
            <motion.div
              className="ticket-roll-empty-badge"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
            >
              LEER
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="ticket-roll-info">
        <div className="ticket-roll-counter">
          <span className="ticket-roll-sold">{sold}</span>
          <span className="ticket-roll-total">/{total}</span>
        </div>
        <div className="ticket-roll-label">verkauft</div>
      </div>
    </div>
  );
});

export default TicketRoll;
