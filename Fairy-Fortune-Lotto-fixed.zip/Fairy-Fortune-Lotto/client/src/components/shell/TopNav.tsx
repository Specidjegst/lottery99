import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DEFAULT_CHAIN, LOTTERY_CONFIG } from "@/lib/config";
import { useWallet, walletLabel } from "@/lib/wallet-mock";
import { AlertTriangle, ChevronDown, Sparkles } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

function NavLink({ href, label, testId }: { href: string; label: string; testId: string }) {
  const [location] = useLocation();
  const active = location === href;
  return (
    <Link
      href={href}
      className={
        "rounded-xl px-3 py-2 text-sm font-medium transition hover:bg-white/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/70 " +
        (active ? "bg-white/7 text-foreground" : "text-muted-foreground")
      }
      data-testid={testId}
    >
      {label}
    </Link>
  );
}

export default function TopNav() {
  const { wallet, connect, disconnect, isWrongNetwork, switchToDefaultNetwork } = useWallet();

  return (
    <div className="sticky top-0 z-50 border-b border-white/10 bg-[linear-gradient(180deg,rgba(10,12,20,0.85),rgba(10,12,20,0.55))] backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <div className="flex items-center gap-3">
          <Link href="/" className="group flex items-center gap-2" data-testid="link-home">
            <div className="grid h-9 w-9 place-items-center rounded-2xl bg-[radial-gradient(circle_at_30%_25%,rgba(34,197,94,0.28),transparent_55%),radial-gradient(circle_at_70%_70%,rgba(99,102,241,0.24),transparent_55%),rgba(255,255,255,0.06)] ring-1 ring-white/10 shadow-[0_20px_80px_-50px_rgba(0,0,0,0.9)]">
              <Sparkles className="h-4 w-4 text-primary" />
            </div>
            <div className="leading-tight">
              <div className="font-serif text-lg tracking-wide text-glow">FaeMillions</div>
              <div className="text-[11px] text-muted-foreground">Ziehung alle 14 Tage · VRF verifizierbar</div>
            </div>
          </Link>

          <div className="hidden items-center gap-1.5 sm:flex">
            <NavLink href="/buy" label="Kaufen" testId="link-buy" />
            <NavLink href="/tickets" label="Meine Tickets" testId="link-tickets" />
            <NavLink href="/results" label="Ergebnisse" testId="link-results" />
            <NavLink href="/history" label="Historie" testId="link-history" />
            <NavLink href="/how" label="So funktioniert’s" testId="link-how" />
            <NavLink href="/faq" label="FAQ" testId="link-faq" />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden md:block">
            <Badge variant="secondary" className="bg-white/6 text-muted-foreground ring-1 ring-white/10">
              {DEFAULT_CHAIN.name}
            </Badge>
          </div>

          {wallet.status !== "connected" ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  className="rounded-2xl bg-[linear-gradient(135deg,rgba(20,184,166,0.95),rgba(99,102,241,0.9))] text-primary-foreground shadow-[0_24px_90px_-60px_rgba(34,197,94,0.5)]"
                  data-testid="button-connect-wallet"
                >
                  Wallet verbinden
                  <ChevronDown className="ml-2 h-4 w-4 opacity-80" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem onClick={() => connect("metamask")} data-testid="button-connect-metamask">
                  MetaMask (EVM)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => connect("phantom")} data-testid="button-connect-phantom">
                  Phantom (EVM)
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <div className="px-2 pb-2 text-xs text-muted-foreground">
                  Demo-Connector · in Produktion würdest du wagmi/rainbowkit nutzen.
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="secondary"
                  className="rounded-2xl bg-white/6 ring-1 ring-white/10"
                  data-testid="button-wallet-menu"
                >
                  {walletLabel(wallet)}
                  <ChevronDown className="ml-2 h-4 w-4 opacity-70" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-72">
                {isWrongNetwork ? (
                  <div className="px-2 py-2">
                    <div className="flex items-start gap-2 rounded-xl bg-red-500/10 p-3 ring-1 ring-red-500/20">
                      <AlertTriangle className="mt-0.5 h-4 w-4 text-red-300" />
                      <div className="space-y-1">
                        <div className="text-sm font-medium" data-testid="status-wrong-network">
                          Falsches Netzwerk
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Bitte wechsle zu <span className="text-foreground">{DEFAULT_CHAIN.name}</span>, um Tickets zu kaufen.
                        </div>
                        <div className="pt-2">
                          <Button size="sm" onClick={switchToDefaultNetwork} data-testid="button-switch-network">
                            Zu {DEFAULT_CHAIN.name} wechseln
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="px-2 py-2">
                    <div className="rounded-xl bg-white/5 p-3 ring-1 ring-white/10">
                      <div className="text-xs text-muted-foreground">Ticketpreis</div>
                      <div className="text-sm font-semibold" data-testid="text-ticket-price">
                        ${LOTTERY_CONFIG.ticketPriceUsd}
                      </div>
                    </div>
                  </div>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={disconnect} data-testid="button-disconnect-wallet">
                  Trennen
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </div>
  );
}
