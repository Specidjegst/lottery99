import { AnimatePresence, motion } from "framer-motion";
import { useLocation } from "wouter";
import TopNav from "./TopNav";
import BottomNav from "./BottomNav";

export default function Shell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen bg-forest reduce-motion">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 noise" />
        <div className="absolute inset-0 opacity-[0.22] bg-[radial-gradient(900px_520px_at_50%_20%,rgba(20,184,166,0.16),transparent_55%),radial-gradient(800px_520px_at_72%_32%,rgba(99,102,241,0.18),transparent_55%)]" />
      </div>

      <TopNav />

      <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-6 sm:px-6 sm:pb-10 sm:pt-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={location}
            initial={{ opacity: 0, y: 10, filter: "blur(6px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, y: -10, filter: "blur(8px)" }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      <BottomNav />
    </div>
  );
}
