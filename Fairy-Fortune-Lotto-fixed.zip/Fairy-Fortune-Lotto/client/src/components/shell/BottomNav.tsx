import { Link, useLocation } from "wouter";
import { Home, Ticket, Wand2, Trophy, History as HistoryIcon } from "lucide-react";

const items = [
  { href: "/", label: "Home", icon: Home, testId: "nav-home" },
  { href: "/buy", label: "Kaufen", icon: Wand2, testId: "nav-buy" },
  { href: "/tickets", label: "Tickets", icon: Ticket, testId: "nav-tickets" },
  { href: "/results", label: "Ergebnisse", icon: Trophy, testId: "nav-results" },
  { href: "/history", label: "Historie", icon: HistoryIcon, testId: "nav-history" },
];

export default function BottomNav() {
  const [location] = useLocation();

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 border-t border-white/10 bg-[linear-gradient(180deg,rgba(10,12,20,0.45),rgba(10,12,20,0.86))] backdrop-blur-xl sm:hidden">
      <div className="mx-auto grid max-w-6xl grid-cols-5 px-2 py-2">
        {items.map((it) => {
          const active = location === it.href;
          const Icon = it.icon;
          return (
            <Link
              key={it.href}
              href={it.href}
              className={
                "flex flex-col items-center justify-center gap-1 rounded-2xl px-2 py-2 text-[11px] transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 " +
                (active ? "bg-white/7 text-foreground" : "text-muted-foreground")
              }
              data-testid={`link-${it.testId}`}
            >
              <Icon className={"h-5 w-5 " + (active ? "text-primary" : "opacity-80")} />
              <span>{it.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
