import React from "react";
import { motion, AnimatePresence } from "framer-motion";

function MiniTicket({ number, style, isWinner = false }) {
  return (
    <motion.div
      className={`mini-ticket ${isWinner ? "winner" : ""}`}
      style={style}
      animate={{
        y: [0, -4, 0],
        rotate: [0, 2, -2, 0],
      }}
      transition={{
        duration: 2 + Math.random() * 2,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    >
      {String(number).padStart(4, "0")}
    </motion.div>
  );
}

export default function Losbox({
  tickets = [],
  isDrawing = false,
  boxRef,
  maxTickets = 100,
}) {
  return (
    <div className="losbox" ref={boxRef}>
      <div className="losbox-frame">
        <div className="losbox-slot" />
        <div className="losbox-inner">
          <AnimatePresence>
            {tickets.map((ticket, i) => {
              const row = Math.floor(i / 4);
              const col = i % 4;
              return (
                <MiniTicket
                  key={ticket.id}
                  number={ticket.number}
                  style={{
                    left: `${10 + col * 22}%`,
                    top: `${10 + row * 28}%`,
                  }}
                />
              );
            })}
          </AnimatePresence>

          {isDrawing && (
            <motion.div
              className="drawing-overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div
                className="drawing-hand"
                animate={{
                  y: [0, 20, 0],
                  rotate: [-5, 5, -5],
                }}
                transition={{
                  duration: 0.5,
                  repeat: Infinity,
                }}
              >
                ✋
              </motion.div>
            </motion.div>
          )}
        </div>
      </div>
      <div className="losbox-caption">
        Losbox · {tickets.length} / {maxTickets} Tickets
      </div>
    </div>
  );
}
