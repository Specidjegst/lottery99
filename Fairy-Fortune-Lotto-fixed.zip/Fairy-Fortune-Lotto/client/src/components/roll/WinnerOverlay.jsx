import React from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function WinnerOverlay({
  isOpen = false,
  winnerNumber,
  onClose,
  drawnNumbers = { main: [], stars: [] },
  prize = "$500",
  lotteryType = "x100",
}) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="winner-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="winner-card"
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            transition={{ type: "spring", damping: 20 }}
          >
            <h2>🎉 {lotteryType.toUpperCase()} Ziehung!</h2>
            <div style={{ fontSize: "28px", fontWeight: 900, color: "var(--gold, #ffd36a)", marginBottom: "16px" }}>
              Gewinn: {prize}
            </div>

            <motion.div
              className="winner-ticket-display"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <div className="winner-ticket-inner">
                <div>
                  <div className="winner-label">Gewinner-Ticket</div>
                  <div className="winner-sublabel">gezogen aus der Losbox</div>
                </div>
                <div className="winner-num">
                  {winnerNumber ? String(winnerNumber).padStart(4, "0") : "----"}
                </div>
              </div>
            </motion.div>

            {drawnNumbers.main.length > 0 && (
              <motion.div
                className="drawn-numbers"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <div className="drawn-row">
                  {drawnNumbers.main.map((n, i) => (
                    <span key={`m-${i}`} className="drawn-ball main">{n}</span>
                  ))}
                </div>
                <div className="drawn-row stars">
                  {drawnNumbers.stars.map((n, i) => (
                    <span key={`s-${i}`} className="drawn-ball star">{n}</span>
                  ))}
                </div>
              </motion.div>
            )}

            <button className="close-btn" onClick={onClose}>
              Schließen
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
