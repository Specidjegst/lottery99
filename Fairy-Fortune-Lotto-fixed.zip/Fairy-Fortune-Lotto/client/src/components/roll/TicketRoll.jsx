import { useState } from "react";
import styles from "./TicketRoll.module.css";

type Props = {
  total: number;
  onBuy?: () => void;
};

export default function TicketRoll({ total, onBuy }: Props) {
  const [sold, setSold] = useState(0);
  const [lastTicket, setLastTicket] = useState<number | null>(null);
  const [animating, setAnimating] = useState(false);

  const buyTicket = async () => {
    if (animating || sold >= total) return;

    setAnimating(true);

    const next = sold + 1;
    setLastTicket(next);

    // Animation Dauer
    await new Promise((r) => setTimeout(r, 900));

    setSold(next);
    setAnimating(false);

    onBuy?.();
  };

  return (
    <div className={styles.wrapper}>
      {/* ROLLE */}
      <div className={styles.dispenser}>
        <img src="/assets/x100-lottery.png" alt="Ticket Rolle" />

        {animating && (
          <div className={styles.ticket}>
            <div className={styles.ticketInner}>
              <div>x100 Lottery</div>
              <span>#{String(lastTicket).padStart(4, "0")}</span>
            </div>
          </div>
        )}
      </div>

      {/* LOSBOX */}
      <div className={styles.box}>
        <div className={styles.slot} />
        <div className={styles.boxContent}>
          {lastTicket && (
            <div className={styles.boxTicket}>
              #{String(lastTicket).padStart(4, "0")}
            </div>
          )}
        </div>
      </div>

      {/* COUNTER */}
      <div className={styles.counter}>
        <span>{sold}</span> / {total}
      </div>

      {/* BUTTON */}
      <button
        className={styles.buy}
        onClick={buyTicket}
        disabled={sold >= total}
      >
        Ticket kaufen – $5
      </button>
    </div>
  );
}