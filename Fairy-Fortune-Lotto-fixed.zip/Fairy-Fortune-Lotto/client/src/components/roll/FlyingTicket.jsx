import React from "react";
import { motion } from "framer-motion";

export default function FlyingTicket({
  number,
  startPos,
  endPos,
  onComplete,
}) {
  if (!startPos || !endPos) return null;

  return (
    <motion.div
      className="flying-ticket"
      initial={{
        position: "fixed",
        left: startPos.x,
        top: startPos.y,
        scale: 1,
        rotate: 0,
        opacity: 1,
        zIndex: 100,
      }}
      animate={{
        left: endPos.x,
        top: endPos.y,
        scale: 0.35,
        rotate: 360,
        opacity: 0.9,
      }}
      transition={{
        duration: 0.8,
        ease: [0.25, 0.46, 0.45, 0.94],
      }}
      onAnimationComplete={onComplete}
    >
      <div className="flying-ticket-inner">
        <div className="ticket-label">
          <div className="ticket-title">Ticket</div>
          <small>x100</small>
        </div>
        <div className="ticket-num">{String(number).padStart(4, "0")}</div>
      </div>
    </motion.div>
  );
}
