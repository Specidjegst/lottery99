import React from "react";
import { MAIN_RANGE, STAR_RANGE } from "../../lib/lottery-utils.js";

function Chip({ active, onClick, children, kind = "main" }) {
  return (
    <button
      type="button"
      className={`chip ${kind} ${active ? "active" : ""}`}
      onClick={onClick}
      aria-pressed={active}
    >
      {children}
    </button>
  );
}

export default function NumberPicker({
  main,
  stars,
  setMain,
  setStars,
  disabled = false,
}) {
  const toggle = (arr, setArr, val, limit) => {
    if (disabled) return;
    const has = arr.includes(val);
    if (has) setArr(arr.filter((x) => x !== val));
    else if (arr.length < limit) setArr([...arr, val]);
  };

  return (
    <div className="picker">
      <div className="pickerHead">
        <div className="pickerTitle">Zahlen (5 aus 50)</div>
        <div className="pickerHint">Tippe zum Auswählen • nochmal tippen zum Entfernen</div>
      </div>

      <div className="grid gridMain">
        {Array.from({ length: MAIN_RANGE }, (_, i) => i + 1).map((n) => (
          <Chip
            key={n}
            kind="main"
            active={main.includes(n)}
            onClick={() => toggle(main, setMain, n, 5)}
          >
            {n}
          </Chip>
        ))}
      </div>

      <div className="pickerSpacer" />

      <div className="pickerHead">
        <div className="pickerTitle">Lucky Stars (2 aus 12)</div>
        <div className="pickerHint">Stars haben eigenen Glow</div>
      </div>

      <div className="grid gridStars">
        {Array.from({ length: STAR_RANGE }, (_, i) => i + 1).map((n) => (
          <Chip
            key={n}
            kind="star"
            active={stars.includes(n)}
            onClick={() => toggle(stars, setStars, n, 2)}
          >
            {n}
          </Chip>
        ))}
      </div>
    </div>
  );
}
