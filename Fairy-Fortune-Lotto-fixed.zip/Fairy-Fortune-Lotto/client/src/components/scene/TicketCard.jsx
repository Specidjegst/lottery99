import React from "react";
import { motion } from "framer-motion";

function Pill({ children, kind = "main", hit = false }) {
  return (
    <span className={`pill ${kind} ${hit ? "hit" : ""}`}>
      {children}
    </span>
  );
}

export default function TicketCard({ ticket, match, isActive = false }) {
  return (
    <motion.div
      className={`ticket ${isActive ? "active" : ""}`}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
    >
      <div className="ticketTop">
        <div className="ticketTitle">Ticket</div>
        <div className="ticketMeta">
          #{String(ticket.id).slice(-6)} • {new Date(ticket.ts).toLocaleString()}
        </div>
      </div>

      <div className="ticketNums">
        <div className="ticketRow">
          {ticket.main.map((n) => (
            <Pill key={`m-${n}`} kind="main" hit={match?.mainHits?.includes(n)}>
              {n}
            </Pill>
          ))}
        </div>
        <div className="ticketRow">
          {ticket.stars.map((n) => (
            <Pill key={`s-${n}`} kind="star" hit={match?.starHits?.includes(n)}>
              {n}
            </Pill>
          ))}
        </div>
      </div>

      <div className="ticketBottom">
        <div className="ticketStatus">
          {ticket.status === "pending" && <span className="status pending">Pending</span>}
          {ticket.status === "drawn" && <span className="status drawn">Drawn</span>}
        </div>

        {match && (
          <div className="ticketMatch">
            <span className="matchChip">{match.main} / 5</span>
            <span className="matchChip star">{match.stars} / 2</span>
          </div>
        )}
      </div>
    </motion.div>
  );
}
