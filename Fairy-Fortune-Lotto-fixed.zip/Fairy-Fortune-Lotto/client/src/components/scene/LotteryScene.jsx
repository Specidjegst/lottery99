import React, { useMemo } from "react";
import { AnimatePresence, motion } from "framer-motion";
import fairyPng from "../../assets/images/fairy.png";

function Ball({ value, kind = "main" }) {
  return (
    <div className={`drawBall ${kind}`}>
      <div className="drawBallInner">{kind === "star" ? `${value}` : value}</div>
    </div>
  );
}

export default function LotteryScene({
  phase = "idle",
  prizeText = "$500000",
  countdownText = "00:00:00",
  drawnMain = [],
  drawnStars = [],
  launch = null,
}) {
  const floatingColors = useMemo(() => {
    const cols = ["c1","c2","c3","c4","c5","c6","c7"];
    return Array.from({ length: 18 }, (_, i) => ({
      cls: cols[i % cols.length],
      x: Math.round(Math.random() * 100),
      y: Math.round(Math.random() * 100),
      d: 2 + Math.random() * 6,
      s: 0.8 + Math.random() * 1.6,
    }));
  }, []);

  const fairyVariants = {
    idle: { x: 0, y: [0, -10, 0], rotate: [0, -1.2, 0], transition: { duration: 4.2, repeat: Infinity } },
    drawing: { x: -28, y: -10, rotate: -3, transition: { duration: 0.7, ease: "easeOut" } },
    reveal: { x: -34, y: -6, rotate: -2, transition: { duration: 0.35 } },
    done: { x: 0, y: [0, -10, 0], rotate: [0, -1.2, 0], transition: { duration: 4.2, repeat: Infinity } },
  };

  const mainTargets = ["-160px","-80px","0px","80px","160px"];
  const starTargets = ["-46px","46px"];

  const target = launch
    ? (launch.kind === "main"
        ? { x: mainTargets[launch.index] ?? "0px", y: "-210px" }
        : { x: starTargets[launch.index] ?? "0px", y: "-138px" })
    : null;

  return (
    <div className="scene">
      <div className="sceneTop">
        <div className="prizeLabel">Prize pool</div>
        <div className="prizeValue">{prizeText}</div>
      </div>

      <div className="machineWrap">
        <div className={`machine ${phase}`}>
          <div className="orb">
            <div className="orbGlow" />

            {floatingColors.map((b, i) => (
              <span
                key={i}
                className={`orbBall ${b.cls}`}
                style={{
                  left: `${b.x}%`,
                  top: `${b.y}%`,
                  animationDuration: `${b.d}s`,
                  transform: `scale(${b.s})`,
                }}
              />
            ))}

            <AnimatePresence>
              {launch && target && (
                <motion.div
                  key={`${launch.kind}-${launch.value}-${launch.index}`}
                  className="launchLayer"
                  initial={{ opacity: 0, scale: 0.7, x: "0px", y: "0px" }}
                  animate={{ opacity: 1, scale: 1.0, x: target.x, y: target.y }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.62, ease: [0.2, 0.9, 0.2, 1] }}
                >
                  <Ball value={launch.value} kind={launch.kind} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <motion.img
            src={fairyPng}
            alt="Fairy"
            className="fairy"
            variants={fairyVariants}
            animate={phase}
          />

          <div className="slots">
            <div className="slotRow main">
              {Array.from({ length: 5 }, (_, i) => (
                <div className="slot" key={i}>
                  {drawnMain[i] ? <Ball value={drawnMain[i]} kind="main" /> : <div className="slotEmpty" />}
                </div>
              ))}
            </div>
            <div className="slotRow stars">
              {Array.from({ length: 2 }, (_, i) => (
                <div className="slot star" key={i}>
                  {drawnStars[i] ? <Ball value={drawnStars[i]} kind="star" /> : <div className="slotEmpty star" />}
                </div>
              ))}
            </div>
          </div>

          <div className="countdown">
            <div className="countdownLabel">Nächste Ziehung</div>
            <div className="countdownValue">{countdownText}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
