import { DEFAULT_CHAIN } from "@/lib/config";
import type { Draw } from "@/lib/lottery";
import { Info, ExternalLink } from "lucide-react";

export default function VrfPanel({ draw }: { draw: Draw }) {
  const requestLink = draw.vrf?.requestTx ? `${DEFAULT_CHAIN.explorerBaseUrl}/tx/${draw.vrf.requestTx}` : undefined;
  const fulfillLink = draw.vrf?.fulfillTx ? `${DEFAULT_CHAIN.explorerBaseUrl}/tx/${draw.vrf.fulfillTx}` : undefined;

  return (
    <div className="glass rounded-3xl p-5" data-testid="panel-vrf">
      <div className="flex items-start gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-2xl bg-white/6 ring-1 ring-white/10">
          <Info className="h-5 w-5 text-primary" />
        </div>
        <div className="min-w-0">
          <div className="font-semibold" data-testid="text-vrf-title">Verifizierbarer Zufall (VRF)</div>
          <div className="mt-1 text-sm text-muted-foreground" data-testid="text-vrf-desc">
            In Produktion würde die Ziehung Zufall über Chainlink VRF anfordern. Jede*r kann Request- und Fulfill-Transaktionen prüfen.
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-2 text-sm">
        <Row k="Ziehung-ID" v={draw.id} testId="text-vrf-drawid" />
        <Row k="VRF request id" v={draw.vrf?.requestId || "—"} testId="text-vrf-requestid" />

        <div className="grid gap-2 sm:grid-cols-2">
          <TxLink label="Request-Transaktion" href={requestLink} testId="link-vrf-request" />
          <TxLink label="Fulfill-Transaktion" href={fulfillLink} testId="link-vrf-fulfill" />
        </div>
      </div>

      <div className="mt-4 rounded-2xl bg-white/4 p-4 ring-1 ring-white/10">
        <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground" data-testid="text-vrf-note-title">
          Demo note
        </div>
        <div className="mt-2 text-sm text-muted-foreground" data-testid="text-vrf-note-body">
          For a production deployment, you’d use <span className="text-foreground">Chainlink Automation</span> to trigger draws on schedule.
          This prototype keeps it functional with a demo “Trigger draw” action.
        </div>
      </div>
    </div>
  );
}

function Row({ k, v, testId }: { k: string; v: string; testId: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="text-muted-foreground" data-testid={`${testId}-k`}>{k}</div>
      <div className="font-mono text-xs text-foreground/90 truncate" data-testid={testId}>{v}</div>
    </div>
  );
}

function TxLink({ label, href, testId }: { label: string; href?: string; testId: string }) {
  if (!href) {
    return (
      <div className="rounded-2xl bg-white/5 px-3 py-2 ring-1 ring-white/10" data-testid={`${testId}-empty`}>
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="text-sm">—</div>
      </div>
    );
  }
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className="group rounded-2xl bg-white/5 px-3 py-2 ring-1 ring-white/10 transition hover:bg-white/7"
      data-testid={testId}
    >
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-0.5 inline-flex items-center gap-1 text-sm">
        View on explorer
        <ExternalLink className="h-3.5 w-3.5 opacity-70 transition group-hover:opacity-100" />
      </div>
    </a>
  );
}
