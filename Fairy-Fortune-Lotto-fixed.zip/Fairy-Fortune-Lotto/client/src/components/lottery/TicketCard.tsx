import { DEFAULT_CHAIN } from "@/lib/config";
import type { Ticket } from "@/lib/lottery";
import { cn } from "@/lib/utils";
import { ExternalLink } from "lucide-react";

function ballClass(kind: "main" | "star") {
  return kind === "star"
    ? "bg-[radial-gradient(circle_at_30%_25%,rgba(250,204,21,0.65),rgba(255,255,255,0.10))] ring-1 ring-yellow-400/25"
    : "bg-[radial-gradient(circle_at_30%_25%,rgba(20,184,166,0.55),rgba(255,255,255,0.10))] ring-1 ring-primary/25";
}

export default function TicketCard({ ticket }: { ticket: Ticket }) {
  const link = ticket.txHash ? `${DEFAULT_CHAIN.explorerBaseUrl}/tx/${ticket.txHash}` : undefined;

  return (
    <div className="glass rounded-3xl p-5" data-testid={`card-ticket-${ticket.id}`}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-xs text-muted-foreground" data-testid={`text-ticket-draw-${ticket.id}`}>Ziehung</div>
          <div className="font-serif text-lg tracking-wide" data-testid={`text-ticket-drawid-${ticket.id}`}>{ticket.drawId}</div>
        </div>
        <div className={cn(
          "rounded-full px-3 py-1 text-xs ring-1",
          ticket.status === "pending" ? "bg-white/6 text-muted-foreground ring-white/10" : ticket.status === "won" ? "bg-primary/12 text-primary ring-primary/25" : "bg-red-500/10 text-red-200 ring-red-500/20",
        )} data-testid={`status-ticket-${ticket.id}`}>
          {ticket.status === "pending" ? "Warten auf Ziehung" : ticket.status === "won" ? `Gewonnen · ${ticket.tier}` : "Verloren"}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        {ticket.numbers.main.map((n) => (
          <div key={n} className={cn("grid h-10 w-10 place-items-center rounded-full text-sm font-semibold", ballClass("main"))} data-testid={`ball-main-${ticket.id}-${n}`}>
            {n}
          </div>
        ))}
        <div className="mx-1 h-6 w-px bg-white/10" />
        {ticket.numbers.stars.map((n) => (
          <div key={n} className={cn("grid h-10 w-10 place-items-center rounded-full text-sm font-semibold", ballClass("star"))} data-testid={`ball-star-${ticket.id}-${n}`}>
            {n}
          </div>
        ))}
      </div>

      <div className="mt-4 flex items-center justify-between gap-3 text-xs text-muted-foreground">
        <div data-testid={`text-ticket-time-${ticket.id}`}>{new Date(ticket.purchasedAt).toLocaleString()}</div>
        {link ? (
          <a
            href={link}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-foreground/90 hover:bg-white/5"
            data-testid={`link-ticket-tx-${ticket.id}`}
          >
            Tx
            <ExternalLink className="h-3.5 w-3.5 opacity-70" />
          </a>
        ) : (
          <div className="opacity-70" data-testid={`text-ticket-tx-none-${ticket.id}`}>No tx</div>
        )}
      </div>
    </div>
  );
}
