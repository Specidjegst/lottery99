import { useCallback } from "react";
import { NumberBall } from "./NumberBall";
import { cn } from "@/lib/utils";

export default function NumberPicker({
  kind,
  min,
  max,
  picks,
  selected,
  onChange,
  label,
  testIdPrefix,
}: {
  kind: "main" | "star";
  min: number;
  max: number;
  picks: number;
  selected: number[];
  onChange: (next: number[]) => void;
  label: string;
  testIdPrefix: string;
}) {
  const toggle = useCallback(
    (n: number) => {
      const exists = selected.includes(n);
      if (exists) {
        onChange(selected.filter((x) => x !== n));
        return;
      }
      if (selected.length >= picks) return;
      onChange([...selected, n]);
    },
    [selected, picks, onChange],
  );

  return (
    <div className="space-y-3" data-testid={`picker-${testIdPrefix}`}
    >
      <div className="flex items-end justify-between gap-3">
        <div>
          <div className="text-sm font-semibold" data-testid={`text-${testIdPrefix}-label`}>{label}</div>
          <div className="text-xs text-muted-foreground" data-testid={`text-${testIdPrefix}-hint`}>
            Pick {picks} · {selected.length}/{picks}
          </div>
        </div>
        <div
          className={cn(
            "rounded-full px-3 py-1 text-xs ring-1",
            selected.length === picks ? "bg-primary/10 text-primary ring-primary/25" : "bg-white/5 text-muted-foreground ring-white/10",
          )}
          data-testid={`status-${testIdPrefix}-count`}
        >
          {selected.length === picks ? "Locked" : "Selecting"}
        </div>
      </div>

      <div
        className="grid grid-cols-6 gap-2 sm:grid-cols-10"
        role="grid"
        aria-label={label}
      >
        {Array.from({ length: max - min + 1 }).map((_, idx) => {
          const value = min + idx;
          const selectedNow = selected.includes(value);
          const disabled = !selectedNow && selected.length >= picks;
          return (
            <NumberBall
              key={value}
              value={value}
              kind={kind}
              selected={selectedNow}
              disabled={disabled}
              onClick={() => toggle(value)}
              testId={`${testIdPrefix}-${value}`}
            />
          );
        })}
      </div>
    </div>
  );
}
