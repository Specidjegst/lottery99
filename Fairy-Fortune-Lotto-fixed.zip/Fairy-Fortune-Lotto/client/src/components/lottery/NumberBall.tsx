import { cn } from "@/lib/utils";

export function NumberBall({
  value,
  kind,
  selected,
  disabled,
  onClick,
  testId,
}: {
  value: number;
  kind: "main" | "star";
  selected?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  testId: string;
}) {
  return (
    <button
      type="button"
      className={cn(
        "group relative grid h-11 w-11 place-items-center rounded-full text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/70",
        "ring-1 ring-white/10",
        selected
          ? kind === "star"
            ? "bg-[radial-gradient(circle_at_30%_25%,rgba(250,204,21,0.65),rgba(99,102,241,0.2)_55%,rgba(255,255,255,0.08))] text-white shadow-[0_30px_90px_-60px_rgba(250,204,21,0.55)]"
            : "bg-[radial-gradient(circle_at_30%_25%,rgba(20,184,166,0.55),rgba(99,102,241,0.18)_55%,rgba(255,255,255,0.08))] text-white shadow-[0_30px_90px_-60px_rgba(20,184,166,0.55)]"
          : "bg-white/5 text-foreground hover:bg-white/7",
        disabled && !selected ? "opacity-40 cursor-not-allowed hover:bg-white/5" : "",
      )
      }
      onClick={onClick}
      disabled={disabled && !selected}
      aria-pressed={selected}
      data-testid={testId}
    >
      <span className="relative z-10">{value}</span>
      <span className={cn("pointer-events-none absolute inset-0 rounded-full opacity-0 blur-md transition group-hover:opacity-40", kind === "star" ? "bg-yellow-400/30" : "bg-primary/35")} />
    </button>
  );
}
