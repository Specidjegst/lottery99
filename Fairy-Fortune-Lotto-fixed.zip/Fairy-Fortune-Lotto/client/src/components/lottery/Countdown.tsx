import { useEffect, useMemo, useState } from "react";

function pad(n: number) {
  return String(n).padStart(2, "0");
}

export default function Countdown({ targetTs }: { targetTs: number }) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const diff = Math.max(0, targetTs - now);

  const parts = useMemo(() => {
    const total = Math.floor(diff / 1000);
    const days = Math.floor(total / (3600 * 24));
    const hours = Math.floor((total % (3600 * 24)) / 3600);
    const mins = Math.floor((total % 3600) / 60);
    const secs = total % 60;
    return { days, hours, mins, secs };
  }, [diff]);

  return (
    <div className="grid grid-cols-4 gap-2" data-testid="countdown">
      <Tile label="Days" value={String(parts.days)} testId="countdown-days" />
      <Tile label="Hours" value={pad(parts.hours)} testId="countdown-hours" />
      <Tile label="Min" value={pad(parts.mins)} testId="countdown-mins" />
      <Tile label="Sec" value={pad(parts.secs)} testId="countdown-secs" />
    </div>
  );
}

function Tile({ label, value, testId }: { label: string; value: string; testId: string }) {
  return (
    <div className="glass neon-ring rounded-2xl px-3 py-3 text-center">
      <div className="font-serif text-2xl tracking-wide" data-testid={`text-${testId}`}>{value}</div>
      <div className="mt-0.5 text-[11px] uppercase tracking-[0.18em] text-muted-foreground" data-testid={`label-${testId}`}>{label}</div>
    </div>
  );
}
