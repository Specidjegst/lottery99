import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { AnimatePresence, motion, useAnimationControls } from "framer-motion";
import TicketRoll from "./components/TicketRoll/TicketRoll.jsx";
import { playTicketBuy, playTicketLand, playShake, playSpin, playWinnerReveal, playWinnerFanfare } from "./lib/sounds.js";
import "./lottery-styles.css";

const LOTTERY_TYPES = {
  x100: { tickets: 100, label: "x100", prize: "$500" },
  x500: { tickets: 500, label: "x500", prize: "$2,500" },
  x1000: { tickets: 1000, label: "x1000", prize: "$5,000" },
  x10000: { tickets: 10000, label: "x10000", prize: "$50,000" },
};

const PRICE = 5;

// UI/Performance: we only render a limited number of tickets inside the box,
// otherwise x10000 will try to render thousands of DOM nodes.
const MAX_BOX_TICKETS = 48;

// Create a nice scattered "pile" position in percentage coordinates (stable).
function createTicketPose(existingPoses) {
  // We place tickets inside a safe area so they never touch the slot.
  // Values are in % of the box.
  const X_MIN = 18, X_MAX = 82;
  const Y_MIN = 28, Y_MAX = 86;

  const minDist = 9; // distance in %-space (roughly)

  for (let attempt = 0; attempt < 22; attempt++) {
    const x = X_MIN + Math.random() * (X_MAX - X_MIN);
    const y = Y_MIN + Math.random() * (Y_MAX - Y_MIN);
    const r = (Math.random() * 18 - 9);
    const s = 0.92 + Math.random() * 0.10;

    const ok = existingPoses.every(p => {
      const dx = p.x - x;
      const dy = p.y - y;
      return (dx * dx + dy * dy) >= (minDist * minDist);
    });
    if (ok) return { x, y, r, s };
  }

  // Fallback: no perfect spot found
  return {
    x: X_MIN + Math.random() * (X_MAX - X_MIN),
    y: Y_MIN + Math.random() * (Y_MAX - Y_MIN),
    r: (Math.random() * 18 - 9),
    s: 0.92 + Math.random() * 0.10,
  };
}

function fmt(n) {
  return String(n).padStart(4, "0");
}

function storageKey(type, addr) {
  return `${type}_lottery_tickets:${addr || "guest"}`;
}

export default function RollApp() {
  const [wallet, setWallet] = useState(null);
  const [lotteryType, setLotteryType] = useState("x100");
  
  const config = LOTTERY_TYPES[lotteryType];
  const TOTAL = config.tickets;
  
  const [nextNumber, setNextNumber] = useState(1);
  const [remaining, setRemaining] = useState(TOTAL);
  const [purchased, setPurchased] = useState([]);
  const [lastTicket, setLastTicket] = useState(null);

  // Visual tickets shown inside the box (limited + stable positions)
  const [boxTickets, setBoxTickets] = useState([]); // [{num, x, y, r, s}]
  
  const [isAnimating, setIsAnimating] = useState(false);
  const [flyingTicket, setFlyingTicket] = useState(null);
  const [isShaking, setIsShaking] = useState(false);
  const [drawPhase, setDrawPhase] = useState(null);
  const [spinningTickets, setSpinningTickets] = useState([]);
  const [risingTicket, setRisingTicket] = useState(null);
  
  const [showWinner, setShowWinner] = useState(false);
  const [winnerNumber, setWinnerNumber] = useState(null);
  
  const portRef = useRef(null);
  const slotRef = useRef(null);
  const boxCardRef = useRef(null);
  
  useEffect(() => {
    const raw = localStorage.getItem(storageKey(lotteryType, wallet));
    if (raw) {
      try {
        const data = JSON.parse(raw);
        setNextNumber(data.nextNumber || 1);
        setRemaining(data.remaining ?? TOTAL);
        setPurchased(data.purchased || []);
        setLastTicket(data.lastTicket || null);
        setBoxTickets(Array.isArray(data.boxTickets) ? data.boxTickets : []);
      } catch {
        resetAll();
      }
    } else {
      resetAll();
    }
  }, [wallet, lotteryType, TOTAL]);
  
  useEffect(() => {
    localStorage.setItem(storageKey(lotteryType, wallet), JSON.stringify({
      nextNumber,
      remaining,
      purchased,
      lastTicket,
      boxTickets,
    }));
  }, [nextNumber, remaining, purchased, lastTicket, boxTickets, wallet, lotteryType]);
  
  const resetAll = () => {
    setNextNumber(1);
    setRemaining(TOTAL);
    setPurchased([]);
    setLastTicket(null);
    setBoxTickets([]);
    setWinnerNumber(null);
    setShowWinner(false);
  };
  
  const sold = TOTAL - remaining;
  const canDraw = remaining === 0 && purchased.length > 0 && !isAnimating && !showWinner;
  
  useEffect(() => {
    if (canDraw) {
      const timer = setTimeout(() => {
        startDrawAuto();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [canDraw]);
  
  const startDrawAuto = async () => {
    if (purchased.length === 0) return;
    
    const winner = purchased[Math.floor(Math.random() * purchased.length)];
    
    setDrawPhase('shake');
    setIsShaking(true);
    playShake();
    const shakeInterval = setInterval(playShake, 200);
    await new Promise(r => setTimeout(r, 1500));
    clearInterval(shakeInterval);
    
    setDrawPhase('spin');
    // Show a random sample for a nicer look
    const sampleCount = Math.min(20, purchased.length);
    const sampled = [];
    const usedIdx = new Set();
    while (sampled.length < sampleCount) {
      const idx = Math.floor(Math.random() * purchased.length);
      if (usedIdx.has(idx)) continue;
      usedIdx.add(idx);
      sampled.push(purchased[idx]);
    }
    setSpinningTickets(sampled);
    playSpin();
    await new Promise(r => setTimeout(r, 2000));
    
    setDrawPhase('reveal');
    setRisingTicket(winner);
    setSpinningTickets([]);
    playWinnerReveal();
    await new Promise(r => setTimeout(r, 1500));
    
    setIsShaking(false);
    setDrawPhase(null);
    setRisingTicket(null);
    setWinnerNumber(winner);
    setShowWinner(true);
    playWinnerFanfare();
  };
  
  const buyTicket = useCallback(async () => {
    if (remaining <= 0 || isAnimating) return;
    
    playTicketBuy();
    setIsAnimating(true);
    const number = nextNumber;
    
    const port = portRef.current?.getBoundingClientRect();
    const slot = slotRef.current?.getBoundingClientRect();
    
    if (port && slot) {
      const startX = port.left + port.width / 2 - 120;
      const startY = port.top + port.height / 2 - 46;
      const endX = slot.left + slot.width / 2 - 120;
      const endY = slot.top + slot.height / 2 + 64;
      
      setFlyingTicket({
        number,
        startX,
        startY,
        endX,
        endY,
      });
    }
  }, [remaining, isAnimating, nextNumber]);
  
  const handleAnimationComplete = useCallback(() => {
    if (flyingTicket) {
      playTicketLand();
      const number = flyingTicket.number;
      setPurchased(prev => [...prev, number]);
      setLastTicket(number);
      setBoxTickets(prev => {
        const next = [...prev];
        const pose = createTicketPose(next);
        next.push({ num: number, ...pose });
        // Keep only the last N tickets in the box for performance
        return next.slice(-MAX_BOX_TICKETS);
      });
      setNextNumber(n => n + 1);
      setRemaining(r => r - 1);
      setFlyingTicket(null);
      setIsAnimating(false);
    }
  }, [flyingTicket]);
  
  const connectDemo = () => {
    setWallet(w => w ? null : "0xFAE...D00D");
  };
  
  const switchLottery = (type) => {
    if (type !== lotteryType) {
      setLotteryType(type);
    }
  };

  return (
    <div className="lottery-app">
      <header className="lottery-header">
        <div className="lottery-selector">
          {Object.entries(LOTTERY_TYPES).map(([key, val]) => (
            <button
              key={key}
              className={`lottery-tab ${lotteryType === key ? "active" : ""}`}
              onClick={() => switchLottery(key)}
            >
              <span className="tab-label">{val.label}</span>
              <span className="tab-prize">{val.prize}</span>
            </button>
          ))}
        </div>
        
        <button className="wallet-btn" onClick={connectDemo}>
          <span className={`dot ${wallet ? "on" : ""}`} />
          {wallet ? wallet : "Wallet verbinden"}
        </button>
      </header>

      <main className="lottery-grid">
        <section className="left-panel">
          <TicketRoll
            remaining={remaining}
            total={TOTAL}
            portRef={portRef}
          />
        </section>

        <section className="right-panel">
          <motion.div 
            className="losbox-card" 
            ref={boxCardRef}
            animate={isShaking ? {
              x: [0, -2, 2, -3, 3, 0],
              rotate: [0, -1.4, 1.2, -1, 1, 0],
            } : {}}
            transition={{ duration: 0.52, repeat: isShaking ? Infinity : 0 }}
          >
            <div className="losbox-slot" ref={slotRef} />
            <div className="losbox-inner">
              {!drawPhase && boxTickets.map((t, idx) => (
                <MiniTicket key={`${t.num}-${idx}`} number={t.num} pose={t} />
              ))}
              
              {drawPhase === 'spin' && spinningTickets.map((num, idx) => (
                <SpinningTicket key={`spin-${num}-${idx}`} number={num} index={idx} total={spinningTickets.length} />
              ))}
              
              {drawPhase === 'reveal' && risingTicket && (
                <RisingTicket number={risingTicket} />
              )}
              
              {!drawPhase && (
                <div className="losbox-pill-wrap">
                  <motion.div 
                    className="losbox-pill"
                    key={lastTicket}
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.22, ease: [0.2, 0.8, 0.2, 1] }}
                  >
                    {lastTicket ? fmt(lastTicket) : "----"}
                  </motion.div>
                </div>
              )}
              
              {drawPhase === 'shake' && (
                <motion.div 
                  className="draw-text"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  Mische...
                </motion.div>
              )}
            </div>
          </motion.div>
          
          <div className="losbox-label">
            Losbox • {purchased.length} Tickets
          </div>
        </section>
      </main>

      <section className="sold-section">
        <div className="sold-num">
          <span className="sold-now">{sold}</span>
          <span className="sold-total">/{TOTAL}</span>
        </div>
        <div className="sold-cap">VERKAUFT</div>
      </section>

      <section className="actions-section">
        <button 
          className="btn-primary" 
          onClick={buyTicket}
          disabled={remaining <= 0 || isAnimating}
        >
          {remaining <= 0 ? "Ausverkauft" : `Ticket kaufen - $${PRICE}`}
        </button>
      </section>

      <AnimatePresence>
        {flyingTicket && (
          <FlyingTicket
            {...flyingTicket}
            lotteryType={config.label}
            onComplete={handleAnimationComplete}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showWinner && (
          <motion.div 
            className="overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowWinner(false)}
          >
            <motion.div 
              className="modal"
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={e => e.stopPropagation()}
            >
              <div className="modal-title">Ziehung</div>
              <div className="winner-ticket">
                <div className="winner-left">
                  <div className="winner-label">Gewinner-Ticket</div>
                  <div className="winner-sub">gezogen aus der Losbox</div>
                </div>
                <div className="winner-num">{fmt(winnerNumber)}</div>
              </div>
              <div className="winner-prize">Gewinn: {config.prize}</div>
              <button className="btn-ghost modal-close" onClick={() => setShowWinner(false)}>
                Schließen
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SpinningTicket({ number, index, total }) {
  const angle = (index / total) * 360;
  const radius = 60;
  
  return (
    <motion.div
      className="mini-ticket"
      initial={{ opacity: 0 }}
      animate={{ 
        opacity: 1,
        rotate: [0, 360],
        x: [
          Math.cos((angle) * Math.PI / 180) * radius,
          Math.cos((angle + 360) * Math.PI / 180) * radius,
        ],
        y: [
          Math.sin((angle) * Math.PI / 180) * radius,
          Math.sin((angle + 360) * Math.PI / 180) * radius,
        ],
      }}
      transition={{
        duration: 0.8,
        repeat: Infinity,
        ease: "linear",
      }}
      style={{
        position: 'absolute',
        left: '50%',
        top: '50%',
        marginLeft: '-24px',
        marginTop: '-14px',
        background: 'rgba(124,92,255,.25)',
        borderColor: 'rgba(124,92,255,.5)',
        color: '#fff',
        boxShadow: '0 0 15px rgba(124,92,255,.4)',
      }}
    >
      {fmt(number)}
    </motion.div>
  );
}

function RisingTicket({ number }) {
  return (
    <div className="rising-ticket-wrap">
      <motion.div
        className="rising-ticket"
        initial={{ y: 60, opacity: 0, scale: 0.5 }}
        animate={{ 
          y: -80, 
          opacity: 1, 
          scale: 1.3,
        }}
        transition={{ 
          duration: 1.2, 
          ease: [0.2, 0.8, 0.2, 1],
        }}
      >
        {fmt(number)}
      </motion.div>
    </div>
  );
}

function MiniTicket({ number, pose }) {
  return (
    <div className="mini-ticket-wrap" style={{ left: `${pose.x}%`, top: `${pose.y}%` }}>
      <motion.div
        className="mini-ticket"
        initial={{ opacity: 0, scale: 0.6 }}
        animate={{ opacity: 1, scale: pose.s, rotate: pose.r }}
        transition={{ duration: 0.24, ease: [0.2, 0.8, 0.2, 1] }}
      >
        {fmt(number)}
      </motion.div>
    </div>
  );
}

function FlyingTicket({ number, startX, startY, endX, endY, lotteryType, onComplete }) {
  const controls = useAnimationControls();

  // Stable rotation per render
  const rot = useMemo(() => (Math.random() * 14 - 7), []);

  useEffect(() => {
    let cancelled = false;

    (async () => {
      // Stage 1: Unroll
      await controls.start({
        x: startX,
        y: startY + 10,
        clipPath: "inset(0% 0 0 0)",
        opacity: 1,
        scale: 1,
        rotate: 0,
        transition: { duration: 0.38, ease: [0.2, 0.8, 0.2, 1] },
      });
      if (cancelled) return;

      // Stage 2: Tear (micro shake)
      await controls.start({
        x: [startX, startX - 2, startX + 2, startX],
        rotate: [0, -1.1, 1.0, 0],
        transition: { duration: 0.16, ease: "easeOut" },
      });
      if (cancelled) return;

      // Stage 3: Fly into the box
      await controls.start({
        x: endX,
        y: endY,
        rotate: rot,
        scale: 0.62,
        opacity: 0,
        transition: { duration: 0.52, ease: [0.2, 0.8, 0.2, 1] },
      });
      if (cancelled) return;

      onComplete?.();
    })();

    return () => {
      cancelled = true;
    };
  }, [controls, startX, startY, endX, endY, rot, onComplete]);

  return (
    <motion.div
      className="flying-ticket"
      initial={{ 
        x: startX, 
        y: startY, 
        clipPath: "inset(100% 0 0 0)",
        opacity: 0,
        scale: 0.985,
        rotate: 0,
      }}
      animate={controls}
      style={{
        top: 0,
        left: 0,
      }}
    >
      <div className="ticket-left">
        <div style={{ fontSize: '18px' }}>{lotteryType} Lottery</div>
        <small>Ticket</small>
      </div>
      <div className="ticket-num">{fmt(number)}</div>
    </motion.div>
  );
}
