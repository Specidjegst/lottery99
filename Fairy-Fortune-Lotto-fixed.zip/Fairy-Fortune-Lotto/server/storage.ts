import { type User, type InsertUser, type Draw, type InsertDraw, type Ticket, type InsertTicket } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getDraw(id: bigint): Promise<Draw | undefined>;
  getCurrentDraw(): Promise<Draw | undefined>;
  getDrawHistory(limit?: number): Promise<Draw[]>;
  upsertDraw(draw: InsertDraw): Promise<Draw>;
  
  getTicket(id: string): Promise<Ticket | undefined>;
  getPlayerTickets(address: string): Promise<Ticket[]>;
  getDrawTickets(drawId: bigint): Promise<Ticket[]>;
  insertTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicket(id: string, data: Partial<Ticket>): Promise<Ticket>;
  
  getLatestEthPrice(): Promise<string | undefined>;
  insertEthPrice(ethUsd: string, source: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private draws: Map<string, Draw>;
  private tickets: Map<string, Ticket>;
  private ethPrices: Array<{ timestamp: Date; ethUsd: string; source: string }>;

  constructor() {
    this.users = new Map();
    this.draws = new Map();
    this.tickets = new Map();
    this.ethPrices = [];
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getDraw(id: bigint): Promise<Draw | undefined> {
    return this.draws.get(id.toString());
  }

  async getCurrentDraw(): Promise<Draw | undefined> {
    const unfulfilled = Array.from(this.draws.values()).filter(d => !d.fulfilled);
    return unfulfilled.sort((a, b) => Number(b.id - a.id))[0];
  }

  async getDrawHistory(limit = 10): Promise<Draw[]> {
    const fulfilled = Array.from(this.draws.values())
      .filter(d => d.fulfilled)
      .sort((a, b) => b.drawAt.getTime() - a.drawAt.getTime());
    return fulfilled.slice(0, limit);
  }

  async upsertDraw(draw: InsertDraw): Promise<Draw> {
    const existing = await this.getDraw(draw.id);
    const fullDraw: Draw = existing 
      ? { ...existing, ...draw, createdAt: existing.createdAt }
      : { ...draw, createdAt: new Date() };
    
    this.draws.set(draw.id.toString(), fullDraw);
    return fullDraw;
  }

  async getTicket(id: string): Promise<Ticket | undefined> {
    return this.tickets.get(id);
  }

  async getPlayerTickets(address: string): Promise<Ticket[]> {
    return Array.from(this.tickets.values())
      .filter(t => t.player.toLowerCase() === address.toLowerCase())
      .sort((a, b) => b.purchasedAt.getTime() - a.purchasedAt.getTime());
  }

  async getDrawTickets(drawId: bigint): Promise<Ticket[]> {
    return Array.from(this.tickets.values())
      .filter(t => t.drawId === drawId)
      .sort((a, b) => b.purchasedAt.getTime() - a.purchasedAt.getTime());
  }

  async insertTicket(ticket: InsertTicket): Promise<Ticket> {
    const fullTicket: Ticket = { ...ticket, purchasedAt: new Date() };
    this.tickets.set(ticket.id, fullTicket);
    return fullTicket;
  }

  async updateTicket(id: string, data: Partial<Ticket>): Promise<Ticket> {
    const existing = this.tickets.get(id);
    if (!existing) {
      throw new Error(`Ticket ${id} not found`);
    }
    const updated = { ...existing, ...data };
    this.tickets.set(id, updated);
    return updated;
  }

  async getLatestEthPrice(): Promise<string | undefined> {
    if (this.ethPrices.length === 0) return undefined;
    return this.ethPrices[this.ethPrices.length - 1].ethUsd;
  }

  async insertEthPrice(ethUsd: string, source: string): Promise<void> {
    this.ethPrices.push({ timestamp: new Date(), ethUsd, source });
  }
}

export const storage = new MemStorage();
