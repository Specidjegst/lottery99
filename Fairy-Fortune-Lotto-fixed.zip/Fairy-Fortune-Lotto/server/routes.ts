import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDrawSchema, insertTicketSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/draws/current", async (req, res) => {
    try {
      const draw = await storage.getCurrentDraw();
      res.json(draw || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch current draw" });
    }
  });

  app.get("/api/draws/:id", async (req, res) => {
    try {
      const id = BigInt(req.params.id);
      const draw = await storage.getDraw(id);
      
      if (!draw) {
        return res.status(404).json({ error: "Draw not found" });
      }
      
      res.json(draw);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch draw" });
    }
  });

  app.get("/api/draws/history", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const history = await storage.getDrawHistory(limit);
      res.json(history);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch draw history" });
    }
  });

  app.post("/api/draws", async (req, res) => {
    try {
      const validated = insertDrawSchema.parse(req.body);
      const draw = await storage.upsertDraw(validated);
      res.json(draw);
    } catch (error) {
      res.status(400).json({ error: "Invalid draw data" });
    }
  });

  app.get("/api/tickets/player/:address", async (req, res) => {
    try {
      const { address } = req.params;
      const tickets = await storage.getPlayerTickets(address);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch player tickets" });
    }
  });

  app.get("/api/tickets/draw/:drawId", async (req, res) => {
    try {
      const drawId = BigInt(req.params.drawId);
      const tickets = await storage.getDrawTickets(drawId);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch draw tickets" });
    }
  });

  app.post("/api/tickets", async (req, res) => {
    try {
      const validated = insertTicketSchema.parse(req.body);
      const ticket = await storage.insertTicket(validated);
      res.json(ticket);
    } catch (error) {
      res.status(400).json({ error: "Invalid ticket data" });
    }
  });

  app.patch("/api/tickets/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const ticket = await storage.updateTicket(id, req.body);
      res.json(ticket);
    } catch (error) {
      res.status(500).json({ error: "Failed to update ticket" });
    }
  });

  app.get("/api/price/eth", async (req, res) => {
    try {
      const price = await storage.getLatestEthPrice();
      res.json({ ethUsd: price || "2000" });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch ETH price" });
    }
  });

  app.post("/api/price/eth", async (req, res) => {
    try {
      const { ethUsd, source } = req.body;
      
      if (!ethUsd || !source) {
        return res.status(400).json({ error: "ethUsd and source required" });
      }
      
      await storage.insertEthPrice(ethUsd, source);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to insert price" });
    }
  });

  return httpServer;
}
