# FaeMillions - Blockchain Lottery dApp

## Overview

FaeMillions is a blockchain lottery web application with a dark fantasy aesthetic. It's a EuroMillions-style lottery where users pick 5 main numbers (1-50) and 2 Lucky Stars (1-12), buy $5 USD tickets, and participate in biweekly draws. The application features wallet integration, Chainlink VRF for verifiable randomness, and animated ball reveal sequences.

The project consists of three main parts:
- **Frontend**: React SPA with dark fantasy UI, wallet connection, number picker, countdown timer, and animated results
- **Backend**: Express API for caching draws, tickets, and price history
- **Smart Contract**: Solidity lottery contract using Chainlink VRF v2.5 for randomness and Chainlink Price Feeds for USD conversion

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, bundled with Vite
- **Routing**: Wouter (lightweight React router)
- **State Management**: React Context for wallet and lottery state, TanStack Query for server state
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom dark fantasy theme (glassmorphism, neon gradients in teal/purple/emerald)
- **Animations**: Framer Motion for page transitions and ball reveal sequences
- **Fonts**: Cinzel (display/serif) and Manrope (body/sans-serif)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` - shared between frontend and backend
- **Storage Pattern**: Interface-based storage abstraction (`IStorage`) with in-memory fallback (`MemStorage`)
- **Build**: esbuild for server bundling, Vite for client

### Smart Contract Architecture
- **Language**: Solidity 0.8.20
- **Framework**: Hardhat for development and deployment
- **Randomness**: Chainlink VRF v2.5 for verifiable on-chain randomness
- **Price Feeds**: Chainlink ETH/USD price feed for dynamic ticket pricing
- **Supported Networks**: Polygon Mumbai, Base Sepolia, Ethereum Sepolia

### Data Models
- **Users**: Basic auth with username/password
- **Draws**: Lottery rounds with timing, prize pool, VRF data, and winning numbers
- **Tickets**: Player entries with selected numbers, draw reference, and claim status
- **Price History**: ETH/USD price tracking

### Key Design Decisions

**Wallet Integration**: Currently uses a mock wallet provider for development. The codebase includes wagmi configuration for real wallet integration with MetaMask and WalletConnect support, but the active implementation is the mock version for demo purposes.

**German Localization**: UI text uses German terminology ("Ziehung" for draw, "Kaufen" for buy) while keeping technical terms in English.

**14-Day Draw Cadence**: Draws occur every two weeks, matching EuroMillions-style lottery timing.

**Prize Tier System**: 13 winner tiers based on number matches, with 100% of ticket sales distributed to winners.

## External Dependencies

### Blockchain Services
- **Chainlink VRF v2.5**: Verifiable random function for fair draw results
- **Chainlink Price Feeds**: ETH/USD conversion for $5 ticket pricing
- **EVM Networks**: Polygon Mumbai, Base Sepolia, or Ethereum Sepolia testnets

### Database
- **PostgreSQL**: Primary data store (configured via `DATABASE_URL` environment variable)
- **Drizzle ORM**: Type-safe database queries and migrations

### Frontend Libraries
- **@tanstack/react-query**: Server state management and caching
- **framer-motion**: Animation library for transitions and reveals
- **wagmi**: Ethereum wallet connection (prepared but using mock in demo)
- **wouter**: Client-side routing

### Development Tools
- **Vite**: Frontend bundler with HMR
- **Hardhat**: Smart contract development and deployment
- **drizzle-kit**: Database schema migrations

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `DEPLOYER_PRIVATE_KEY`: Wallet key for contract deployment
- `VRF_SUBSCRIPTION_ID`: Chainlink VRF subscription ID
- `VITE_LOTTERY_CONTRACT_ADDRESS`: Deployed contract address
- `VITE_WALLETCONNECT_PROJECT_ID`: WalletConnect integration (optional)