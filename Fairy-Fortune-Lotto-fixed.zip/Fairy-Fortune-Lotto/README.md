# 🎰 Fairy Lottery - Blockchain Lottery dApp

A production-ready biweekly lottery web application with EVM wallet integration, Chainlink VRF for verifiable randomness, and a dark fantasy aesthetic. Users buy $5 USD tickets, participate in draws every 14 days, and watch a fairy mascot perform animated reveals.

![Dark Fantasy Theme](https://img.shields.io/badge/Theme-Dark_Fantasy-blueviolet)
![Blockchain](https://img.shields.io/badge/Blockchain-EVM_Compatible-blue)
![VRF](https://img.shields.io/badge/Chainlink-VRF_v2.5-red)
![License](https://img.shields.io/badge/License-MIT-green)

## ✨ Features

### 🎨 Frontend
- **Dark Fantasy UI**: Glassmorphism panels, neon gradients (teal/purple/emerald), forest background
- **Wallet Integration**: MetaMask, WalletConnect, Phantom support via wagmi + RainbowKit
- **Number Picker**: Select 5 main numbers (1-50) + 2 stars (1-12) with quick-pick
- **Countdown Timer**: Real-time countdown to next draw (14-day cadence)
- **Ball Reveal Animation**: Framer Motion animations with glow, scale, rotation, particle bursts
- **Prize Pool Display**: Dynamic calculation based on tickets sold × $5 USD
- **VRF Panel**: Shows Chainlink VRF request/fulfill transaction hashes
- **Full German Localization**: "Ziehung" terminology throughout

### ⛓️ Blockchain (Smart Contract)
- **EuroMillions-style Format**: 5 main numbers + 2 star numbers
- **Chainlink VRF v2.5**: Verifiable on-chain randomness
- **Dynamic Pricing**: $5 USD ticket price (auto-converts to ETH via Chainlink Price Feed)
- **14-Day Draw Cadence**: Automatic draw timing
- **Prize Distribution**: 100% of ticket sales distributed across 13 winner tiers
- **Claiming**: Winners claim prizes on-chain after draw fulfillment

### 🔧 Backend API
- **Express + PostgreSQL**: REST API for caching draws, tickets, price history
- **Event Indexing**: Listens to smart contract events (DrawFulfilled, TicketPurchased)
- **ETH/USD Price Feed**: Syncs with Chainlink or CoinGecko
- **Player Ticket History**: Query tickets by wallet address

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- MetaMask or compatible wallet

### Installation

```bash
# Clone repository
git clone https://github.com/yourname/fairy-lottery.git
cd fairy-lottery

# Install dependencies
npm install

# Start in mockup mode (no blockchain)
npm run dev
```

Frontend runs at **http://localhost:5000**

## 🌐 Production Deployment (Testnet)

### **Option 1: Frontend-Only Mockup**
Current setup works out of the box - all lottery logic runs in browser with mock wallet.

### **Option 2: Full Blockchain dApp**

Follow the **[Complete Deployment Guide](./DEPLOYMENT_GUIDE.md)** for step-by-step instructions:

1. **Get Testnet Tokens** (Mumbai MATIC + LINK)
2. **Create Chainlink VRF Subscription**
3. **Deploy Smart Contract**
4. **Configure Frontend** with contract address
5. **Install Web3 Dependencies**:
   ```bash
   npm install wagmi viem @tanstack/react-query @rainbow-me/rainbowkit
   npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox @chainlink/contracts dotenv ethers
   ```
6. **Run Full Stack**:
   ```bash
   # Compile contract
   npm run compile
   
   # Deploy to Polygon Mumbai
   npm run deploy:mumbai
   
   # Start frontend + backend
   npm run dev
   ```

**See [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) for complete instructions.**

## 📁 Project Structure

```
fairy-lottery/
├── contracts/                    # Solidity smart contracts
│   └── FairyLottery.sol         # Main lottery contract with Chainlink VRF
├── scripts/                      # Deployment & management scripts
│   ├── deploy.js                # Hardhat deployment script
│   ├── request-draw.js          # Manually trigger draw
│   └── setup-vrf.md             # VRF setup guide
├── client/                       # React frontend
│   ├── src/
│   │   ├── pages/               # Main pages (Home, Buy, Results, etc.)
│   │   ├── components/          # Reusable components
│   │   ├── lib/
│   │   │   ├── contracts/       # Contract ABIs + wagmi hooks
│   │   │   ├── lottery-store.tsx    # Mock lottery state (for dev)
│   │   │   ├── wallet-mock.tsx      # Mock wallet (for dev)
│   │   │   └── web3-config.ts       # wagmi/RainbowKit config
│   │   └── assets/              # Images (fairy, particles, forest)
│   └── index.html               # Entry point
├── server/                       # Express backend
│   ├── routes.ts                # API endpoints
│   └── storage.ts               # Storage interface (Memory/PostgreSQL)
├── shared/                       # Shared types
│   └── schema.ts                # Drizzle ORM schema (draws, tickets, price)
├── hardhat.config.js            # Hardhat config (Mumbai/Base/Sepolia)
├── .env.example                 # Environment variables template
├── DEPLOYMENT_GUIDE.md          # Complete deployment instructions
└── README.md                    # This file
```

## 🎮 How to Use

### Mockup Mode (Default)
1. Visit http://localhost:5000
2. "Connect Wallet" → simulated MetaMask/Phantom
3. Navigate to **Kaufen** (Buy Tickets)
4. Select numbers or use quick-pick
5. Add to cart and "purchase" (local only)
6. Go to **Ergebnisse** (Results) → click **"Enthüllung starten"** to see ball reveal animation

### Web3 Mode (After Deployment)
1. Connect real wallet (MetaMask)
2. Ensure correct network (Polygon Mumbai / Base Sepolia)
3. Buy tickets → approve transaction (costs testnet MATIC + $5 in ETH)
4. Wait for draw time (14 days)
5. Owner triggers `requestDraw()` → Chainlink VRF fulfills
6. View results → claim prizes if you won

## 🏗️ Architecture

```
┌─────────────────────────────────────────┐
│           Frontend (React+Vite)         │
│   ┌─────────────────────────────────┐   │
│   │  wagmi + RainbowKit Providers   │   │
│   │  (Wallet connection, hooks)     │   │
│   └──────────────┬──────────────────┘   │
│                  │                       │
│   ┌──────────────▼──────────────────┐   │
│   │  Lottery UI Components          │   │
│   │  (Buy, Results, History, etc.)  │   │
│   └─────────────────────────────────┘   │
└──────────────┬──────────────────────────┘
               │
               ├──── Wallet (MetaMask/WC)
               │
┌──────────────▼──────────────────────────┐
│      Smart Contract (FairyLottery)      │
│  ┌────────────────────────────────────┐ │
│  │  • buyTicket(numbers, stars)       │ │
│  │  • requestDraw() → VRF Request     │ │
│  │  • fulfillRandomWords() ← VRF      │ │
│  │  • claimPrize(drawId, ticketIdx)   │ │
│  └────────────────────────────────────┘ │
└──────────────┬──────────────────────────┘
               │
               ├──── Chainlink VRF v2.5 (randomness)
               ├──── Chainlink Price Feed (ETH/USD)
               │
┌──────────────▼──────────────────────────┐
│      Backend API (Express+PostgreSQL)   │
│  ┌────────────────────────────────────┐ │
│  │  Event Indexer (TicketPurchased,   │ │
│  │  DrawFulfilled, etc.)              │ │
│  │                                    │ │
│  │  REST API:                         │ │
│  │  • GET /api/draws/current          │ │
│  │  • GET /api/tickets/player/:addr   │ │
│  │  • GET /api/price/eth              │ │
│  └────────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

## 🧪 Testing

### Local Frontend Testing (No Blockchain)
```bash
npm run dev
```
Uses mock wallet + in-memory lottery store.

### Testnet Testing (Full Stack)
1. Deploy to Polygon Mumbai (cheapest gas):
   ```bash
   npm run deploy:mumbai
   ```
2. Fund VRF subscription with 10 LINK
3. Add contract as VRF consumer
4. Update `.env` with contract address
5. Test full flow:
   - Buy tickets (real transactions)
   - Wait for draw time or manually trigger
   - Claim prizes

### Contract Testing (Hardhat)
```bash
# Compile
npm run compile

# Run tests (TODO: add test files)
npx hardhat test

# Deploy to local network
npx hardhat node
npx hardhat run scripts/deploy.js --network localhost
```

## 🎨 Customization

### Change Theme Colors
Edit `client/src/index.css`:
```css
:root {
  --primary: 173 100% 49%;        /* Teal */
  --accent: 267 84% 71%;          /* Purple */
  --emerald: 160 84% 39%;         /* Emerald */
}
```

### Change Lottery Parameters
Edit `contracts/FairyLottery.sol`:
```solidity
uint256 public constant TICKET_PRICE_USD = 5e8; // $5
uint256 public constant DRAW_CADENCE = 14 days; // 2 weeks
uint8 public constant MAIN_NUMBERS = 5;         // 5 main
uint8 public constant STAR_NUMBERS = 2;         // 2 stars
```

### Change Prize Distribution
Edit prize tier weights in `FairyLottery.sol` → `_calculatePrize()`:
```solidity
uint256[13] memory tierWeights = [
    uint256(5200), // Tier 1 (5+2): 52%
    1800,          // Tier 2 (5+1): 18%
    // ... adjust as needed
];
```

## 📊 Prize Tiers

| Tier | Match   | % of Pool | Example Prize* |
|------|---------|-----------|----------------|
| 1    | 5 + 2   | 52%       | Jackpot        |
| 2    | 5 + 1   | 18%       | $90,000        |
| 3    | 5 + 0   | 10%       | $50,000        |
| 4    | 4 + 2   | 6%        | $15,000        |
| 5    | 4 + 1   | 4%        | $7,500         |
| 6    | 3 + 2   | 3%        | $3,000         |
| 7    | 4 + 0   | 2%        | $1,500         |
| 8    | 2 + 2   | 1.5%      | $750           |
| 9    | 3 + 1   | 1.2%      | $500           |
| 10   | 3 + 0   | 1%        | $300           |
| 11   | 1 + 2   | 0.8%      | $150           |
| 12   | 2 + 1   | 0.3%      | $50            |
| 13   | 2 + 0   | 0.2%      | $25            |

*Example based on 10,000 tickets sold ($50,000 total pool)

## 🔐 Security Considerations

### ⚠️ Important Notes
- **Smart Contract NOT Audited**: Do NOT use on mainnet without professional audit
- **Testnet Only**: This is a template for learning/prototyping
- **Private Keys**: Never commit private keys to git
- **Legal Compliance**: Check local gambling laws before mainnet deployment
- **VRF Costs**: Budget ~0.5-1 LINK per draw on mainnet

### Production Checklist
- [ ] Smart contract security audit
- [ ] Legal review for gambling/lottery regulations
- [ ] Mainnet Chainlink VRF subscription with sufficient LINK
- [ ] Frontend deployed with SSL (Vercel/Netlify)
- [ ] Backend with rate limiting, CORS, authentication
- [ ] Database backups and monitoring
- [ ] Gas optimization review
- [ ] Emergency pause mechanism
- [ ] Multi-sig owner wallet

## 🛠️ Tech Stack

### Frontend
- **React 19** + **Vite** - Fast build tool
- **wagmi** + **RainbowKit** - Web3 wallet connection
- **Framer Motion** - Animations
- **Tailwind CSS v4** - Styling with dark theme
- **Wouter** - Lightweight routing
- **TanStack Query** - Data fetching

### Backend
- **Express** - API server
- **PostgreSQL** + **Drizzle ORM** - Database
- **Node.js** - Runtime

### Blockchain
- **Solidity 0.8.20** - Smart contract language
- **Hardhat** - Development environment
- **Chainlink VRF v2.5** - Verifiable randomness
- **Chainlink Price Feeds** - ETH/USD conversion
- **OpenZeppelin** - Security libraries

## 📚 Documentation

- **[Complete Deployment Guide](./DEPLOYMENT_GUIDE.md)** - Step-by-step testnet deployment
- **[VRF Setup Guide](./scripts/setup-vrf.md)** - Chainlink VRF configuration
- **[Hardhat Config](./hardhat.config.js)** - Network settings
- **[API Documentation](#api-endpoints)** - Backend REST API reference

## 🌍 Supported Networks

### Testnets (Recommended)
- **Polygon Mumbai** (Chain ID: 80001) - Cheapest gas ✅
- **Base Sepolia** (Chain ID: 84532) - L2 with low fees
- **Ethereum Sepolia** (Chain ID: 11155111) - Main testnet

### Mainnet (Requires Audit)
- Polygon (recommended for low gas)
- Ethereum
- Base
- Arbitrum
- Optimism

## 📡 API Endpoints

### Draws
- `GET /api/draws/current` - Get current open draw
- `GET /api/draws/:id` - Get specific draw by ID
- `GET /api/draws/history?limit=10` - Get past draws
- `POST /api/draws` - Create/update draw (admin)

### Tickets
- `GET /api/tickets/player/:address` - Get all tickets for wallet
- `GET /api/tickets/draw/:drawId` - Get all tickets for draw
- `POST /api/tickets` - Record ticket purchase
- `PATCH /api/tickets/:id` - Update ticket (tier, claimed)

### Price
- `GET /api/price/eth` - Get latest ETH/USD price
- `POST /api/price/eth` - Update price (from oracle)

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

MIT License - see [LICENSE](./LICENSE) for details.

## 🙏 Acknowledgments

- **Chainlink** - VRF and Price Feeds
- **RainbowKit** - Beautiful wallet UI
- **EuroMillions** - Lottery format inspiration
- **Replit** - Development platform

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/yourname/fairy-lottery/issues)
- **Chainlink Docs**: https://docs.chain.link/vrf
- **wagmi Docs**: https://wagmi.sh

---

**Built with ❤️ for Web3 and Dark Fantasy**

🧚 May the fairy bring you luck! 🎰
