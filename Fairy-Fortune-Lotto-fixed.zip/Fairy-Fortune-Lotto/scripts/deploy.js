const hre = require("hardhat");

const NETWORKS = {
  polygonMumbai: {
    vrfCoordinator: "0x7a1BaC17Ccc5b313516C5E16fb24f7659aA5ebed",
    keyHash: "0x4b09e658ed251bcafeebbc69400383d49f344ace09b9576fe248bb02c003fe9f",
    ethUsdPriceFeed: "0x0715A7794a1dc8e42615F059dD6e406A6594651A",
    linkToken: "0x326C977E6efc84E512bB9C30f76E30c160eD06FB",
  },
  baseSepolia: {
    vrfCoordinator: "0x5C210eF41CD1a72de73bF76eC39637bB0d3d7BEE",
    keyHash: "0xc799bd1e3bd4d1a41cd4968997a4e03dfd2a3c7c04b695881138580163f42887",
    ethUsdPriceFeed: "0x4aDC67696bA383F43DD60A9e78F2C97Fbbfc7cb1",
    linkToken: "0xE4aB69C077896252FAFBD49EFD26B5D171A32410",
  },
  sepolia: {
    vrfCoordinator: "0x9DdfaCa8183c41ad55329BdeeD9F6A8d53168B1B",
    keyHash: "0x787d74caea10b2b357790d5b5247c2f63d1d91572a9846f780606e4d953677ae",
    ethUsdPriceFeed: "0x694AA1769357215DE4FAC081bf1f309aDC325306",
    linkToken: "0x779877A7B0D9E8603169DdbD7836e478b4624789",
  },
};

async function main() {
  const networkName = hre.network.name;
  console.log(`\n🚀 Deploying FairyLottery to ${networkName}...\n`);

  if (!NETWORKS[networkName]) {
    throw new Error(`Network ${networkName} not configured. Use: polygonMumbai, baseSepolia, or sepolia`);
  }

  const config = NETWORKS[networkName];

  const subscriptionId = process.env.VRF_SUBSCRIPTION_ID;
  if (!subscriptionId) {
    throw new Error(
      "❌ VRF_SUBSCRIPTION_ID not set!\n" +
      "Create a subscription at: https://vrf.chain.link\n" +
      "Then set VRF_SUBSCRIPTION_ID in .env"
    );
  }

  const callbackGasLimit = 500000;

  console.log("📋 Deployment parameters:");
  console.log("  VRF Coordinator:", config.vrfCoordinator);
  console.log("  Subscription ID:", subscriptionId);
  console.log("  Key Hash:", config.keyHash);
  console.log("  Callback Gas Limit:", callbackGasLimit);
  console.log("  ETH/USD Price Feed:", config.ethUsdPriceFeed);
  console.log("");

  const FairyLottery = await hre.ethers.getContractFactory("FairyLottery");
  const lottery = await FairyLottery.deploy(
    config.vrfCoordinator,
    subscriptionId,
    config.keyHash,
    callbackGasLimit,
    config.ethUsdPriceFeed
  );

  await lottery.waitForDeployment();
  const address = await lottery.getAddress();

  console.log("✅ FairyLottery deployed to:", address);
  console.log("");

  console.log("📝 Next steps:");
  console.log("1. Add this contract as a VRF consumer:");
  console.log(`   https://vrf.chain.link (Subscription ID: ${subscriptionId})`);
  console.log("");
  console.log("2. Fund your subscription with LINK tokens:");
  console.log(`   LINK Token: ${config.linkToken}`);
  console.log("   Recommended: 10 LINK for testing");
  console.log("");
  console.log("3. Update frontend config:");
  console.log(`   VITE_LOTTERY_CONTRACT_ADDRESS=${address}`);
  console.log(`   VITE_CHAIN_ID=${hre.network.config.chainId}`);
  console.log("");

  if (networkName !== "hardhat" && networkName !== "localhost") {
    console.log("⏳ Waiting 60s before verifying contract...");
    await new Promise((resolve) => setTimeout(resolve, 60000));

    try {
      await hre.run("verify:verify", {
        address: address,
        constructorArguments: [
          config.vrfCoordinator,
          subscriptionId,
          config.keyHash,
          callbackGasLimit,
          config.ethUsdPriceFeed,
        ],
      });
      console.log("✅ Contract verified on block explorer");
    } catch (error) {
      console.log("⚠️  Verification failed:", error.message);
    }
  }

  console.log("\n🎉 Deployment complete!\n");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
