const hre = require("hardhat");

async function main() {
  const contractAddress = process.env.LOTTERY_CONTRACT_ADDRESS;
  
  if (!contractAddress) {
    throw new Error("LOTTERY_CONTRACT_ADDRESS not set in .env");
  }

  console.log(`\n🎲 Requesting draw for FairyLottery at ${contractAddress}...\n`);

  const FairyLottery = await hre.ethers.getContractFactory("FairyLottery");
  const lottery = FairyLottery.attach(contractAddress);

  const currentDraw = await lottery.getCurrentDraw();
  console.log("📋 Current Draw:");
  console.log("  Draw ID:", currentDraw.id.toString());
  console.log("  Draw Time:", new Date(Number(currentDraw.drawAt) * 1000).toISOString());
  console.log("  Tickets Sold:", currentDraw.ticketsSold.toString());
  console.log("  Prize Pool:", hre.ethers.formatEther(currentDraw.prizePool), "ETH");
  console.log("");

  const now = Math.floor(Date.now() / 1000);
  if (now < currentDraw.drawAt) {
    console.log("⏰ Draw time not reached yet. Wait until:", new Date(Number(currentDraw.drawAt) * 1000).toISOString());
    return;
  }

  if (currentDraw.fulfilled) {
    console.log("✅ Draw already fulfilled!");
    return;
  }

  console.log("🔄 Requesting VRF randomness...");
  const tx = await lottery.requestDraw();
  console.log("  Transaction:", tx.hash);
  
  const receipt = await tx.wait();
  console.log("  Gas used:", receipt.gasUsed.toString());
  console.log("");

  console.log("✅ VRF request sent!");
  console.log("⏳ Waiting for Chainlink to fulfill (1-2 minutes)...");
  console.log("   Check VRF dashboard: https://vrf.chain.link");
  console.log("");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
