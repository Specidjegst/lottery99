# Chainlink VRF Setup Guide

## Prerequisites
- Testnet wallet with some ETH (for gas)
- Testnet LINK tokens

## Step-by-Step Setup

### 1. Get Testnet ETH
**Polygon Mumbai:**
- https://faucet.polygon.technology/

**Base Sepolia:**
- https://www.coinbase.com/faucets/base-ethereum-sepolia-faucet

**Ethereum Sepolia:**
- https://sepoliafaucet.com/

### 2. Get Testnet LINK
**Polygon Mumbai:**
- https://faucets.chain.link/mumbai

**Base Sepolia:**
- https://faucets.chain.link/base-sepolia

**Ethereum Sepolia:**
- https://faucets.chain.link/sepolia

### 3. Create VRF Subscription
1. Go to https://vrf.chain.link
2. Connect your wallet (select correct testnet)
3. Click "Create Subscription"
4. Confirm transaction
5. **Save your Subscription ID** → you'll need this for deployment

### 4. Fund Subscription with LINK
1. In the VRF dashboard, select your subscription
2. Click "Add funds"
3. Enter amount (recommended: **10 LINK** for testing)
4. Confirm transaction

### 5. Deploy Lottery Contract
```bash
# Set your subscription ID in .env
echo "VRF_SUBSCRIPTION_ID=YOUR_SUBSCRIPTION_ID" >> .env

# Deploy to testnet
npm run deploy:mumbai
# or
npm run deploy:base-sepolia
```

### 6. Add Contract as Consumer
1. After deployment, go back to https://vrf.chain.link
2. Select your subscription
3. Click "Add consumer"
4. Enter your **deployed contract address** (from deployment output)
5. Confirm transaction

### 7. Test the Lottery
```bash
# Request a draw (after draw time passes)
npx hardhat run scripts/request-draw.js --network polygonMumbai

# Wait ~1-2 minutes for Chainlink to fulfill
# Check fulfillment on-chain or in your frontend
```

## Troubleshooting

### "InsufficientBalance" error
- Your subscription needs more LINK tokens
- Add at least 2-5 LINK per draw request

### VRF request never fulfilled
- Check consumer is added to subscription
- Verify subscription has enough LINK
- Wait 2-3 minutes (Chainlink needs time to fulfill)
- Check VRF dashboard for request status

### Contract not verified on block explorer
- Wait 1-2 minutes after deployment
- Run verification manually:
  ```bash
  npx hardhat verify --network polygonMumbai DEPLOYED_ADDRESS "constructor" "args" "here"
  ```

## Network Details

### Polygon Mumbai (Testnet - RECOMMENDED)
- Chain ID: 80001
- RPC: https://rpc-mumbai.maticvigil.com
- Block Explorer: https://mumbai.polygonscan.com
- VRF Coordinator: `0x7a1BaC17Ccc5b313516C5E16fb24f7659aA5ebed`

### Base Sepolia (Testnet)
- Chain ID: 84532
- RPC: https://sepolia.base.org
- Block Explorer: https://sepolia.basescan.org
- VRF Coordinator: `0x5C210eF41CD1a72de73bF76eC39637bB0d3d7BEE`

### Ethereum Sepolia (Testnet)
- Chain ID: 11155111
- RPC: https://rpc.sepolia.org
- Block Explorer: https://sepolia.etherscan.io
- VRF Coordinator: `0x9DdfaCa8183c41ad55329BdeeD9F6A8d53168B1B`

## Cost Estimates

**Per Draw (VRF Request + Fulfillment):**
- LINK cost: ~0.5-1 LINK
- Gas cost (Polygon Mumbai): ~0.01 MATIC
- Gas cost (Base/Sepolia): ~0.0005 ETH

**For Testing (10 draws):**
- Fund subscription with: **10 LINK**
- Wallet needs: **0.1 ETH** (gas)
