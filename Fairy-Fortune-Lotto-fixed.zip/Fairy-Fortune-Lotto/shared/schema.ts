import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb, boolean, bigint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const draws = pgTable("draws", {
  id: bigint("id", { mode: "bigint" }).primaryKey(),
  startsAt: timestamp("starts_at").notNull(),
  drawAt: timestamp("draw_at").notNull(),
  ticketsSold: integer("tickets_sold").notNull().default(0),
  prizePool: varchar("prize_pool", { length: 78 }).notNull().default("0"),
  vrfRequestId: varchar("vrf_request_id", { length: 78 }),
  fulfilled: boolean("fulfilled").notNull().default(false),
  mainNumbers: jsonb("main_numbers").$type<number[]>(),
  starNumbers: jsonb("star_numbers").$type<number[]>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const tickets = pgTable("tickets", {
  id: varchar("id", { length: 66 }).primaryKey(),
  drawId: bigint("draw_id", { mode: "bigint" }).notNull().references(() => draws.id),
  player: varchar("player", { length: 42 }).notNull(),
  mainNumbers: jsonb("main_numbers").$type<number[]>().notNull(),
  starNumbers: jsonb("star_numbers").$type<number[]>().notNull(),
  txHash: varchar("tx_hash", { length: 66 }),
  claimed: boolean("claimed").notNull().default(false),
  tier: integer("tier").default(0),
  purchasedAt: timestamp("purchased_at").notNull().defaultNow(),
});

export const priceHistory = pgTable("price_history", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  ethUsd: varchar("eth_usd", { length: 32 }).notNull(),
  source: varchar("source", { length: 50 }).notNull(),
});

export const insertDrawSchema = createInsertSchema(draws).omit({
  createdAt: true,
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  purchasedAt: true,
});

export const insertPriceHistorySchema = createInsertSchema(priceHistory).omit({
  id: true,
  timestamp: true,
});

export type Draw = typeof draws.$inferSelect;
export type InsertDraw = z.infer<typeof insertDrawSchema>;

export type Ticket = typeof tickets.$inferSelect;
export type InsertTicket = z.infer<typeof insertTicketSchema>;

export type PriceHistory = typeof priceHistory.$inferSelect;
export type InsertPriceHistory = z.infer<typeof insertPriceHistorySchema>;
